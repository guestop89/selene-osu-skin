"""SELENE V1 / AzuRT — rounded competition-oriented UI, original osu! profile avatar."""
from pathlib import Path
import sys,json,re,shutil,zipfile,math,base64,wave
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageOps
import build_selene as b
ROOT=b.ROOT; OUT=b.OUT
BASE=ROOT/'work'/'SELENE v0.9 - AzuRT'
if not BASE.exists(): BASE=ROOT/'work'/'v1-base'
DEST=ROOT/'work'/'SELENE V1 Realease'; NAME='SELENE V1 Realease'; PREFIX='SELENE-V1'
AVATAR=ROOT/'work'/'v1-assets'/'osu-avatar-38408224.png'
COMIC=Path('C:/Windows/Fonts/comic.ttf'); BOLD=Path('C:/Windows/Fonts/comicbd.ttf')
W,H,N,J=320,14,360,42
COLORS=[(255,139,197),(191,153,255),(231,158,245)]

def font(size,bold=False): return ImageFont.truetype(str(BOLD if bold else COMIC),max(1,round(size*b.S)))
class Canvas(b.Canvas):
    def text(self,xy,t,size=20,fill=b.WHITE,style='regular',anchor='mm'):
        self.d.text(tuple(round(v*b.S) for v in xy),t,font=font(size,style=='bold'),fill=fill,anchor=anchor)
C=Canvas

def glyph(name,ch,w,h,fs,col=(255,250,255),bold=False):
    c=C(w,h); raw=Image.new('RGBA',(w*b.S*4,h*b.S*4)); d=ImageDraw.Draw(raw)
    d.text((w*b.S,h*b.S),ch,font=font(fs,bold),fill=col)
    a=raw.crop(raw.getbbox()); c.im.alpha_composite(a,(round(w*b.S/2-a.width/2),round(h*b.S/2-a.height/2))); c.save(name)

def shapes_and_fonts():
    # White outline and shaded centre from the supplied gameplay reference.
    c=C(128,128); c.ellipse((5,5,123,123),(100,100,112,62),(255,255,255,225),3.6)
    c.ellipse((10,10,118,118),None,(255,255,255,65),1); c.save('hitcircle')
    c=C(128,128); c.ellipse((5,5,123,123),None,(255,253,255,245),2.15)
    c.ellipse((10,10,118,118),None,(255,250,255,85),.65)
    c.line([(25,19),(31,16)],(255,255,255,120),1.1); c.save('hitcircleoverlay')
    for src,dst in [('hitcircle','sliderstartcircle'),('hitcircleoverlay','sliderstartcircleoverlay')]:
        for s in ['', '@2x']: shutil.copyfile(DEST/(src+s+'.png'),DEST/(dst+s+'.png'))
    c=C(128,128); c.ellipse((4,4,124,124),None,(255,255,255,180),1.9); c.save('approachcircle')
    c=C(128,128); c.ellipse((8,8,120,120),(230,224,246,10),(255,255,255,235),2.5)
    c.ellipse((57,57,71,71),(255,253,255,230)); c.save('sliderb0')
    for prefix,w,h,fs,bold in [('default',42,58,48,True),('score',29,42,33,True),('combo',33,50,43,False),('scoreentry',12,18,14,True)]:
        for ch in '0123456789': glyph(prefix+'-'+ch,ch,w,h,fs,bold=bold)
    for prefix,w,h,fs in [('score',29,42,33),('combo',33,50,34),('scoreentry',12,18,14)]:
        for token,ch,ww in [('dot','.',max(6,w//2)),('comma',',',max(6,w//2)),('percent','%',w+8)]: glyph(prefix+'-'+token,ch,ww,h,fs,bold=prefix!='combo')
        if prefix!='combo': glyph(prefix+'-x','x',max(8,w-3),h,fs)
    # Native formatCount = count + 'x'. The x glyph is the word from the reference.
    c=C(133,50); c.text((8,26),'Combo',32,(126,116,198),'regular','lm'); c.save('combo-x')
    glyph('score-pp','pp',44,42,24,(186,177,232))
    # A transparent backing leaves the reference-style combo free-standing.
    b.empty('halo-combo-plate')

def cursor_asset(size,folder):
    n=size*4; yy,xx=np.mgrid[0:n,0:n]; r=np.hypot(xx-n/2,yy-n/2)/(n/2)
    core=np.exp(-(r/.255)**10); alpha=np.minimum(1,core+.47*np.exp(-(r/.46)**2)+.10*np.exp(-(r/.73)**4))*np.clip((1-r)/.15,0,1)
    rgb=np.zeros((n,n,3))+np.array([250,245,255]); rgb=rgb*(1-core[...,None])+255*core[...,None]
    im=Image.fromarray(np.uint8(np.dstack([rgb,alpha*255])))
    im.resize((size*2,size*2),Image.Resampling.LANCZOS).save(folder/'cursor@2x.png'); im.resize((size,size),Image.Resampling.LANCZOS).save(folder/'cursor.png')

def cursor_and_options():
    cursor_asset(80,DEST)
    options=ROOT/'work'/'V1-cursor-options'; options.mkdir(exist_ok=True)
    for size,label in [(64,'Compact'),(80,'Equilibre'),(96,'Large')]:
        p=options/label; p.mkdir(exist_ok=True); cursor_asset(size,p)
    guide='''Trois tailles du même curseur blanc : Compact 64 px, Equilibre 80 px (défaut V1), Large 96 px. Dans stable, copier les deux PNG du dossier choisi à la racine de la copie du skin, puis recharger le skin. Dans lazer, utiliser le flux d'édition/import de skin ou ajuster simplement Taille du curseur dans les options. Ces dossiers ne sont pas des .osk autonomes. Aucun changement automatique des paramètres du client. Le réglage Taille du curseur reste le moyen le plus simple d'adapter le rendu à sa résolution et sa préférence.'''
    (options/'LISEZ-MOI.txt').write_text(guide,encoding='utf8')
    with zipfile.ZipFile(OUT/(PREFIX+'-tailles-curseur.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        for p in options.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(options).as_posix())

def bounce_judgements():
    for name,col in [('hit100',(166,231,184)),('hit100k',(166,231,184)),('hit50',(168,202,240)),('hit0',(243,155,186))]:
        for i in range(J):
            t=i/(J-1); c=C(100,100)
            opacity=math.sin(t/.14*math.pi/2)**2 if t<.14 else (1 if t<.30 else (.5+.5*math.cos((t-.30)/.70*math.pi))**1.15)
            a=round(opacity*220)
            if name=='hit0':
                d=4.2; c.line([(50-d,50-d),(50+d,50+d)],(*col,a),1.8); c.line([(50+d,50-d),(50-d,50+d)],(*col,a),1.8)
            else:
                c.text((50,51),':3',27,(6,6,12,round(a*.45)),'bold'); c.text((50,50),':3',27,(*col,a),'bold')
            # Small elastic settle akin to a cartoon counter, fixed visual centre.
            if t<.28:
                q=t/.28-1; back=1+2.2*q**3+1.2*q**2; scale=.78+.22*back
            else: scale=1-.065*max(0,(t-.62)/.38)
            stretch=.065*math.sin(min(1,t/.28)*math.pi)*math.exp(-t*8)
            im=c.image(); w=round(200*scale*(1+stretch)); h=round(200*scale*(1-stretch))
            small=im.resize((w,h),Image.Resampling.LANCZOS); out=Image.new('RGBA',(200,200)); out.alpha_composite(small,((200-w)//2,(200-h)//2))
            out.save(DEST/f'{name}-{i}@2x.png',optimize=True); out.resize((100,100),Image.Resampling.LANCZOS).save(DEST/f'{name}-{i}.png',optimize=True)
            if i==12: out.save(DEST/(name+'@2x.png')); out.resize((100,100),Image.Resampling.LANCZOS).save(DEST/(name+'.png'))
    for n in ['hit300','hit300k','hit300g']: b.empty(n)

def profile_and_health():
    c=C(412,79)
    # One connected housing: bar, lower identity row and avatar share its outline.
    c.box((1,8,409,75),(14,12,22,235),(119,99,147,190),1.25,r=12)
    c.box((4,11,406,72),None,(229,215,246,30),.7,r=10)
    c.box((3,12,330,34),(8,8,14,245),(81,66,108,230),1,r=9)
    c.line([(16,38),(326,38)],(114,91,143,90),.65)
    c.ellipse((13,47,25,59),(206,188,233,235)); c.ellipse((18,44,28,55),(14,12,22,255))
    c.text((33,54),'Sélène',15,(231,220,247),'bold','lm')
    c.line([(99,46),(99,63)],(128,105,155,100),.7)
    for j,col in enumerate([(0,0,145),(255,255,255),(225,0,15)]): c.box((113+j*5,48,117+j*5,59),col)
    c.box((112.5,47.5,128.5,60),None,(233,218,248,90),.5,r=1)
    c.text((139,54),'AzuRT',19,(252,246,255),'bold','lm')
    c.text((311,55),'osu!',11,(177,158,205),'regular','rm')
    # The exact public osu! avatar is fitted as an image resource; no AI redraw.
    c.box((337,4,402,69),(8,8,15,255),(176,151,205,210),1.5,r=10)
    avatar=ImageOps.fit(Image.open(AVATAR).convert('RGBA'),(57*b.S,57*b.S),Image.Resampling.LANCZOS)
    mask=Image.new('L',avatar.size); ImageDraw.Draw(mask).rounded_rectangle((0,0,avatar.width-1,avatar.height-1),7*b.S,fill=255)
    avatar.putalpha(mask); c.im.alpha_composite(avatar,(341*b.S,8*b.S)); c.save('scorebar-bg')
    scale=4; yy,xx=np.mgrid[0:H*scale,0:W*scale]; u=xx/(W*scale-1); v=yy/(H*scale-1)
    mask=Image.new('L',(W*scale,H*scale)); ImageDraw.Draw(mask).rounded_rectangle((0,0,W*scale-1,H*scale-1),6*scale,fill=255); edge_mask=np.array(mask)/255
    base=np.array([221,137,188])*(1-u[...,None])+np.array([155,126,218])*u[...,None]
    for i in range(N):
        phase=i/N*math.tau; surface=.24+.07*(.5-.5*np.cos(phase))+.05*np.sin(u*math.tau*1.1-phase)
        edge=np.clip((v-surface)*H*scale+.5,0,1)
        crest=np.exp(-((v-surface)/.045)**2)*.52
        rgb=base+(np.array([255,239,252])-base)*crest[...,None]
        rgb+=(255-rgb)*np.exp(-((v-surface-.22)/.16)**2)[...,None]*.10
        im=Image.fromarray(np.uint8(np.dstack([np.clip(rgb,0,255),edge*edge_mask*236])))
        hd=im.resize((W*2,H*2),Image.Resampling.LANCZOS); sd=im.resize((W,H),Image.Resampling.LANCZOS)
        hd.save(DEST/f'scorebar-colour-{i}@2x.png',optimize=True); sd.save(DEST/f'scorebar-colour-{i}.png',optimize=True)
        if i==0: hd.save(DEST/'scorebar-colour@2x.png'); sd.save(DEST/'scorebar-colour.png')
    print('Connected HUD with original osu! avatar ready',flush=True)

def ui():
    for name,label,sub in [('pause-continue','Continuer','GO'),('pause-retry','Recommencer','RETRY'),('pause-back','Retour','BACK'),('pause-replay','Revoir','REPLAY')]:
        c=C(320,76); c.box((3,10,317,69),(17,14,28,235),(126,107,160,220),1.3,r=13)
        c.line([(23,12),(111,12)],(237,222,252,70),1)
        c.text((26,38),label,21,(251,245,255),'bold','lm'); c.text((294,39),sub,11,(184,171,220),'regular','rm'); c.save(name)
    c=C(200,96); c.box((1,33,193,95),(17,14,28,230),(126,107,160,200),1.1,r=12); c.line([(28,54),(18,64),(28,74)],(230,209,245),2)
    c.text((44,64),'Retour',20,b.WHITE,'bold','lm'); c.save('menu-back')
    for name,label,key,w in [('mode','Mode','F1',92),('mods','Mods','F2',77),('random','Hasard','F3',77),('options','Options','F4',77)]:
        for over in [False,True]:
            c=C(w,90); c.box((3,12,w-3,88),(42,29,60,235) if over else (18,15,28,210),(178,143,207,230) if over else (114,95,145,170),1,r=10)
            if name!='mode': c.text((w/2,38),key,13,(207,189,235),'bold')
            c.text((w/2,71),label,11,(249,241,255),'bold'); c.save('selection-'+name+('-over' if over else ''))
    for name,title in [('pause-overlay','Une petite pause.'),('fail-background','On recommence ?')]:
        c=C(1366,768,(8,7,13,216)); c.text((683,119),title,31,b.WHITE,'bold'); c.text((683,700),'Sélène · AzuRT',13,(173,151,197)); c.save(name)
    for name,label in [('ranking-title','Bien joué !'),('ranking-accuracy','Précision'),('ranking-maxcombo','Combo max'),('ranking-perfect','Parfait !')]:
        c=C(330,52); c.text((165,26),label,23,(243,231,253),'bold'); c.save(name)
    for grade,col in [('X',(242,225,254)),('XH',(255,250,255)),('S',(243,173,215)),('SH',(255,250,255)),('A',(216,190,246)),('B',(199,174,229)),('C',(194,173,215)),('D',(224,162,193))]:
        label='SS' if grade.startswith('X') else grade[0]
        for small in [False,True]:
            w,h=(42,30) if small else (240,160); c=C(w,h); c.text((w/2,h/2),label,24 if small else 106,col,'bold'); c.save('ranking-'+grade+('-small' if small else ''))
    mods={'easy':'EZ','nofail':'NF','halftime':'HT','hardrock':'HR','suddendeath':'SD','perfect':'PF','doubletime':'DT','nightcore':'NC','hidden':'HD','flashlight':'FL','relax':'RX','relax2':'AP','spunout':'SO','autoplay':'AT','cinema':'CN','target':'TP','scorev2':'V2','mirror':'MR','random':'RD','keycoop':'CO'}
    mods.update({f'key{i}':f'{i}K' for i in range(1,10)})
    for name,label in mods.items():
        c=C(68,58); c.box((2,5,66,53),(20,16,31,230),(132,108,162,160),1,r=9); c.text((34,28),label,23,(225,205,246),'bold'); c.save('selection-mod-'+name)
    for name,label,fs,w,h in [('play-skip','Passer',22,180,60),('ready','Prêt ?',38,300,90),('go','Go !',45,220,90),('spinner-spin','Tourne !',24,220,70),('spinner-clear','Bien joué',23,220,70),('spinner-warning','Tourne !',24,220,70),('section-pass','Ça roule !',26,320,75),('section-fail','On se reprend.',25,320,75)]:
        c=C(w,h); c.text((w/2,h/2),label,fs,(240,226,252),'bold'); c.save(name)
    for i in [1,2,3]:
        c=C(110,100); c.text((55,50),str(i),54,(246,233,255),'bold'); c.save('count'+str(i))
    c=C(246,56); c.box((1,1,245,55),None,(130,107,160,85),.8,r=10); c.text((15,18),'Précision',10,(200,181,219),'bold','lm'); c.text((15,39),'sur 100',8,(167,146,189),'regular','lm'); c.save('halo-accuracy-plate')
    c=C(214,64); c.box((1,1,213,63),(17,14,26,110),(130,107,160,80),.8,r=10); c.text((15,15),'Performance',9,(192,170,214),'bold','lm'); c.save('prism-pp-card')
    # New abstract menu artwork is code-native, not a painted replacement avatar.
    saved=b.FONT.copy(); b.FONT.update(regular='comic.ttf',light='comic.ttf',bold='comicbd.ttf',mono='comic.ttf')
    b.build_background(); b.FONT.clear(); b.FONT.update(saved)

def config_and_layout():
    txt=(BASE/'skin.ini').read_text(encoding='utf8'); txt=re.sub(r'^Name: .*$', 'Name: '+NAME,txt,flags=re.M); txt=re.sub(r'^// Release: .*$', '// Release: 1.0 / AzuRT',txt,flags=re.M)
    txt=re.sub(r'^CursorExpand: .*$', 'CursorExpand: 0',txt,flags=re.M)
    txt=re.sub(r'^HitCircleOverlap: .*$', 'HitCircleOverlap: 6',txt,flags=re.M)
    txt=re.sub(r'^ComboOverlap: .*$', 'ComboOverlap: 1',txt,flags=re.M)
    for i,col in enumerate(COLORS,1): txt=re.sub(rf'^Combo{i}: .*$',f'Combo{i}: '+','.join(map(str,col)),txt,flags=re.M)
    (DEST/'skin.ini').write_text(txt,encoding='utf8')
    data=json.loads((BASE/'MainHUDComponents.json').read_text(encoding='utf8'))
    for element in data['DrawableInfo']['osu']:
        if 'LegacyDefaultComboCounter' in element['Type']:
            element['Position']={'X':20,'Y':-22}; element['Scale']={'X':.82,'Y':.82}
    (DEST/'MainHUDComponents.json').write_text(json.dumps(data,indent=2),encoding='utf8')

def draw_textures(im,string,xy,prefix='score',scale=.7):
    x,y=xy
    for ch in string:
        n='percent' if ch=='%' else 'dot' if ch=='.' else ch
        a=b.sprite(prefix+'-'+n); a=a.resize((round(a.width*scale),round(a.height*scale)),Image.Resampling.LANCZOS); im.alpha_composite(a,(round(x),round(y))); x+=a.width-round((2 if prefix=='combo' else 4)*scale)

def scene():
    im=Image.new('RGBA',(1280,720),(8,7,13)); d=ImageDraw.Draw(im)
    d.rounded_rectangle((775,352,1085,456),52,fill=(13,11,20),outline=(149,133,171),width=2)
    for x,y,n,col in [(365,437,1,COLORS[0]),(485,290,2,COLORS[1]),(690,220,3,COLORS[2]),(828,404,4,COLORS[0])]:
        if n in [2,3]: b.paste_center(im,b.sprite('approachcircle'),(x,y),(167 if n==2 else 215,)*2)
        a=np.array(b.sprite('hitcircle')); a[:,:,:3]=(a[:,:,:3].astype(float)*np.array(col)/255).astype(np.uint8)
        b.paste_center(im,Image.fromarray(a),(x,y),(104,104)); b.paste_center(im,b.sprite('hitcircleoverlay'),(x,y),(104,104)); b.paste_center(im,b.sprite('default-'+str(n)),(x,y),(34,47))
    for j in range(8,0,-1):
        a=b.sprite('cursortrail').resize((36,36)); a.putalpha(a.getchannel('A').point(lambda z:round(z*(1-j/9)))); b.paste_center(im,a,(350-j*8,423+j*3))
    b.paste_center(im,b.sprite('cursor'),(350,423),(80,80))
    im.alpha_composite(b.sprite('scorebar-bg').resize((412,79)),(0,0)); a=b.sprite('scorebar-colour-90').resize((W,H)); im.alpha_composite(a.crop((0,0,275,H)),(5,16))
    draw_textures(im,'01284350',(958,12),scale=.65)
    im.alpha_composite(b.sprite('halo-accuracy-plate').resize((246,56)),(1028,51)); draw_textures(im,'99.42%',(1101,61),scale=.48)
    im.alpha_composite(b.sprite('prism-pp-card').resize((214,64)),(1048,122)); draw_textures(im,'245',(1132,145),scale=.5); b.paste_center(im,b.sprite('score-pp'),(1240,166),(30,30))
    draw_textures(im,'438x',(27,650),'combo',.65)
    return im

def previews():
    c=C(1920,1460,(8,7,13,255)); c.text((64,64),'Sélène',32,(245,232,255),'bold','lm'); c.text((1856,64),'V1 · AzuRT',18,(195,177,223),'bold','rm')
    c.text((64,145),'Clair à lire. Agréable à jouer.',45,(253,248,255),'bold','lm'); c.text((66,208),'Ronds clairs · chiffres arrondis · combo vivant · vrai avatar osu!',18,(182,166,205),'regular','lm')
    im=c.im.resize((1920,1460),Image.Resampling.LANCZOS); im.alpha_composite(scene(),(64,250))
    text=C(510,760); text.text((0,42),'Une lecture plus directe.',24,(237,225,250),'bold','lm'); text.text((0,90),'Bords blancs, centre sombre,',20,(185,169,208),'regular','lm'); text.text((0,124),'chiffres plus grands et arrondis.',20,(185,169,208),'regular','lm')
    text.text((0,400),'Tout le profil est relié.',24,(237,225,250),'bold','lm'); text.text((0,447),'Ta pp osu!, ton pseudo, le drapeau :',18,(185,169,208),'regular','lm'); text.text((0,482),'un seul petit bloc, sans faux score.',18,(185,169,208),'regular','lm')
    text.text((0,585),'Un petit rebond.',24,(237,225,250),'bold','lm'); text.text((0,632),'Combo natif animé à chaque hit,',18,(185,169,208),'regular','lm'); text.text((0,667),'smiley droit et apparition souple.',18,(185,169,208),'regular','lm')
    im.alpha_composite(text.image().resize((510,760)),(1370,250))
    for j,col in enumerate(COLORS):
        a=np.array(b.sprite('hitcircle')); a[:,:,:3]=(a[:,:,:3].astype(float)*np.array(col)/255).astype(np.uint8); x=1430+j*145
        b.paste_center(im,Image.fromarray(a),(x,500),(116,116)); b.paste_center(im,b.sprite('hitcircleoverlay'),(x,500),(116,116))
    for j,name in enumerate(['hit100','hit50','hit0']): b.paste_center(im,b.sprite(name),(1435+j*140,955),(100,100))
    d=ImageDraw.Draw(im); d.line((64,1040,1856,1040),fill=(52,40,65)); im.alpha_composite(b.sprite('scorebar-bg'),(64,1105)); im.alpha_composite(b.sprite('scorebar-colour-60'),(74,1137))
    detail=C(1000,200); detail.text((0,36),'Le combo de ta référence.',29,(242,229,253),'bold','lm'); detail.text((0,91),'Chiffres blancs + « Combo » violet, fond transparent.',20,(201,183,222),'regular','lm'); detail.text((0,148),'Le jaune automatique tous les 100 exige plus qu’un .osk.',17,(159,144,180),'regular','lm'); im.alpha_composite(detail.image().resize((1000,200)),(925,1100))
    footer=C(1800,35); footer.text((0,17),'Composition hors jeu · scores illustratifs · pas de réglage universel ni de certification pro',12,(136,122,155),'regular','lm'); im.alpha_composite(footer.image().resize((1800,35)),(64,1395))
    im.convert('RGB').save(OUT/(PREFIX+'-apercu.jpg'),quality=95,subsampling=0)
    # Simulate the source-documented native small combo bump with real sprite glyphs.
    frames=[]
    for i in range(150):
        t=i/25; im=Image.new('RGBA',(760,310),(8,7,13)); d=ImageDraw.Draw(im); d.text((25,18),'Sélène V1 / AzuRT',font=ImageFont.truetype(str(BOLD),21),fill=(237,226,250))
        im.alpha_composite(b.sprite('scorebar-bg').resize((577,111)),(85,52)); im.alpha_composite(b.sprite(f'scorebar-colour-{round(t*60)%N}').resize((448,20)),(92,74))
        phase=t%(.24); count=94+int(t/.24); bump=1+.10*math.sin(math.pi*min(1,phase/.10)) if phase<.10 else 1
        layer=Image.new('RGBA',(450,90)); draw_textures(layer,str(count)+'x',(0,20),'combo',.75)
        layer=layer.resize((round(450*bump),round(90*bump)),Image.Resampling.LANCZOS); im.alpha_composite(layer,(42,190-round((bump-1)*20)))
        fr=min(J-1,round((t%1)*60)); b.paste_center(im,b.sprite('hit100-'+str(fr)),(560,223),(100,100))
        d=ImageDraw.Draw(im); d.text((25,286),'SIMULATION HORS JEU / REBOND NATIF / AUCUN JAUNE CONDITIONNEL DANS LE .OSK',font=ImageFont.truetype(str(COMIC),10),fill=(144,130,163)); frames.append(im.convert('RGB'))
    frames[0].save(OUT/(PREFIX+'-mouvement.gif'),save_all=True,append_images=frames[1:],duration=40,loop=0)

def docs(report):
    guide='''# SÉLÈNE V1 / AzuRT

Importer SELENE V1 Realease.osk dans osu!, puis sélectionner le skin. Version complète. Le skin.ini garde Version: 2.7 (version du format legacy) ; la release est bien V1 / 1.0.

## Les deux références
Cercles à bord blanc net, intérieur sombre légèrement teinté de rose/violet/orchidée, grand chiffre arrondi. C'est une interprétation originale du rendu fourni, sans reprendre les fichiers du skin tiers. Les approches restent plus fines que les notes, parfait masqué et peu de particules pour garder l'écran clair.
Chiffres et textes skinnables rendus avec Comic Sans MS / Comic Sans MS Bold de Windows, plus naturels et cartoon. Ce sont des PNG ; aucune police à installer ni fichier de police Windows distribué. Les textes natifs de lazer peuvent conserver leur police système.

## Le vrai combo du jeu
Les chiffres de combo sont blancs ; le suffixe natif x est remplacé graphiquement par le mot Combo violet, selon la seconde capture. Le compteur n'est pas une image fixe : il affiche bien le combo réel. Le composant LegacyDefaultComboCounter de lazer réalise un rebond natif à chaque incrément et un effet de pop-out. Le skin exploite cette animation avec des glyphes arrondis et un compteur sans panneau massif. L'amplitude et le timing exacts restent ceux du client.
Limite non résolue par le format : un .osk seul ne peut pas tester Combo % 100 == 0 pour passer le texte en jaune. Cette fonction n'est pas implémentée dans le pack et n'est pas montrée dans la galerie comme si elle fonctionnait en jeu. Une logique conditionnelle nécessiterait un composant/client ou un overlay distinct ; aucun programme externe n'est installé.

## :3 cartoon et fluide
:3 vert pour 100, bleu pour 50, croix rose pour miss, parfait invisible. Dessin arrondi de 27 px, petit rebond élastique, très léger squash/stretch puis fondu. 42 images à 60 i/s. Le centre reste près de la note ; dans cette V1 les symboles restent droits pour se lire rapidement. Pas de position ou d'orientation aléatoire par hit. Le son de miss reste le combobreak discret soumis aux règles du jeu.

## Tout le HUD de vie est relié
Une coque unique arrondie rassemble le liquide rose/violet, le logo Sélène, le drapeau français, AzuRT et la vraie photo de profil du compte osu! 38408224. L'image originale vient de https://a.ppy.sh/38408224 et n'est pas redessinée par IA. Le pseudo est la personnalisation confirmée AzuRT ; aucune statistique ou classement n'est inventé.
Le remplissage reste 320×14 px à l'origine native (5,16), avec 360 images à 60 i/s en boucle de six secondes. Le moteur garde le contrôle de la valeur de vie et de son lissage.

## Réglages raisonnables, à adapter
Curseur blanc équilibré de 80 px, stable au clic (CursorExpand: 0), centre fixe, traînée blanche courte sans cursormiddle. Le jeu conserve ses paramètres de taille, sensibilité, résolution, AR/CS et vitesse de défilement. Un skin ne peut pas choisir un réglage optimal universel pour tous les joueurs.
Commencer vers 1× pour la taille du curseur, puis adapter à son écran et à sa préférence. Des variantes 64/80/96 px sont fournies dans SELENE-V1-tailles-curseur.zip ; ajuster la taille dans les options du jeu reste le plus simple. Commencer avec un fond très assombri si la carte gêne la lecture. Les options de couleurs de beatmap peuvent remplacer les trois combos du skin.
Les hitsounds courts de la v0.9 sont conservés. Pour les entendre, vérifier les réglages d'échantillons/hitsounds de beatmaps et le volume des effets. Le .osk ne force pas un volume et n'ajoute pas un clic aux entrées ratées.

## Compatibilité et vérification
Format legacy : assets de menu visant stable ; pp, accuracy et layout personnalisés pour lazer. Stable ne calcule pas les pp avec le .osk seul. Les autres modes gardent leurs assets spécifiques ; les images partagées, les polices de compteurs et les sons communs évoluent. Les touches et la vitesse de mania restent inchangées.
Archive, images SD/@2x, 360 frames de vie, 42 frames de jugements, présence du suffixe Combo, configuration du composant natif, absence de clipping des glyphes et fichiers audio vérifiés techniquement. Pas de test d'import ou de gameplay en client pour cette V1 : confort, placement et performances doivent encore être évalués sur ta configuration. La galerie montre les vraies frames et des simulations explicites, pas des captures du client. Les scores sont illustratifs.

## Sources
https://github.com/ppy/osu/blob/master/osu.Game/Skinning/LegacyDefaultComboCounter.cs
https://osu.ppy.sh/wiki/en/Skinning/Interface
https://osu.ppy.sh/users/38408224
Design original AzuRT × Codex. Avatar original du compte indiqué, utilisé à la demande de l'utilisateur. Glyphes Windows rasterisés, aucune fonte Windows distribuée.
Sources modifiables dans SELENE-V1-sources.zip : Python 3.12+ avec Pillow et numpy sous Windows, scripts dans work/, avatar dans work/v1-assets/ et base complète dans work/v1-base/. Exécuter build_selene_v1.py. La base source incluse permet de reconstruire sans rejouer toutes les versions précédentes.
'''
    (DEST/'LISEZ-MOI.txt').write_text(guide,encoding='utf8'); (OUT/(PREFIX+'-guide.md')).write_text(guide,encoding='utf8')
    (DEST/'FONT-CREDITS.txt').write_text('V1 : glyphes de Comic Sans MS et Comic Sans MS Bold, polices Windows rasterisées localement. Aucun fichier de fonte Windows distribué. Les fichiers PNG sont les ressources utilisées par le jeu.\n',encoding='utf8')
    photo=base64.b64encode((OUT/(PREFIX+'-apercu.jpg')).read_bytes()).decode(); gif=base64.b64encode((OUT/(PREFIX+'-mouvement.gif')).read_bytes()).decode(); bg=base64.b64encode((DEST/'scorebar-bg.png').read_bytes()).decode()
    waves=[base64.b64encode((DEST/f'scorebar-colour-{i}.png').read_bytes()).decode() for i in range(N)]
    clicks=base64.b64encode((DEST/'normal-hitnormal.wav').read_bytes()).decode()
    html='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sélène V1 / AzuRT</title><style>*{box-sizing:border-box}body{margin:0;background:#08070d;color:#f7effc;font:17px/1.65 'Comic Sans MS','Comic Sans',cursive}main{max-width:1280px;padding:50px 28px;margin:auto}h1{font-size:clamp(34px,6vw,60px);line-height:1.15}h2{font-size:28px;margin-top:45px}.muted{color:#ae9bbf}.button,button{display:inline-block;font:inherit;color:#ead8f8;background:#1a1425;border:1px solid #725888;border-radius:13px;text-decoration:none;padding:13px 21px;margin:0 12px 12px 0;cursor:pointer}img{max-width:100%;border-radius:10px}.hero{width:100%;margin-top:25px}.demo{overflow:auto;background:#100c18;border:1px solid #3d2b4d;padding:30px 20px;border-radius:14px}.bar{position:relative;width:412px;height:79px;margin:auto;background-image:url('data:image/png;base64,__BG__');background-size:412px 79px}#wave{position:absolute;width:320px;height:14px;left:5px;top:16px}.note{border-left:3px solid #9478b0;padding:4px 20px;margin:30px 0}.combo{display:inline-flex;align-items:baseline;gap:8px;font-size:46px;transform-origin:left bottom}.combo small{font-size:31px;color:#7e74c6}.pop{animation:pop 100ms ease-out}@keyframes pop{0%{transform:scale(1)}50%{transform:scale(1.1)}100%{transform:scale(1)}}footer{border-top:1px solid #3d2b4d;margin-top:50px;padding:25px 0}a{color:#ddc4f0}</style><main><p class="muted">Sélène / V1 / AzuRT</p><h1>Clair à lire.<br>Agréable à jouer.</h1><p class="muted">Bords blancs, chiffres arrondis et une interface cartoon cohérente. Ton vrai avatar osu!, ton pseudo et ton drapeau dans un bloc relié.</p><a class="button" href="SELENE%20V1%20Realease.osk">Télécharger la V1 complète</a><a class="button" href="SELENE-V1-guide.md">Lire le guide</a><img class="hero" src="data:image/jpeg;base64,__PHOTO__" alt="Composition des cercles V1, du combo blanc et violet, du HUD relié et de l'avatar osu!"><h2>Un seul bloc, bien aligné.</h2><div class="demo"><div class="bar"><img id="wave" alt="Vraie barre de vie du pack avec avatar et drapeau"></div></div><h2>Le combo de ta référence.</h2><div class="combo" id="combo"><span id="value">6</span><small>Combo</small></div><p><button id="hit">+1 combo</button><button id="reset">Repartir à zéro</button><button onclick="let a=document.getElementById('click');a.currentTime=0;a.volume=.5;a.play().catch(()=>{})">▶ Écouter le clic</button><audio id="click" src="data:audio/wav;base64,__SOUND__"></audio></p><p class="muted">Cette prévisualisation reproduit le petit rebond natif avec une approximation CSS. Le jeu anime réellement son compteur LegacyDefaultComboCounter. Le suffixe du pack est bien le mot « Combo ».</p><div class="note">Le passage automatique du texte en jaune tous les 100 combos n'est pas disponible dans le .osk : cette condition n'est pas implémentée, et le compteur ci-dessus ne simule pas cette fonction comme si elle marchait en jeu.</div><h2>Un smiley souple, un curseur stable.</h2><img src="data:image/gif;base64,__GIF__" width="760" height="310" alt="Simulation du combo, de la vie et du :3 en rebond"><p>Curseur blanc de 80 px sans agrandissement au clic, :3 droit avec petit rebond puis fondu. Plusieurs tailles de curseur sont proposées pour adapter le rendu à ton écran et ta préférence.</p><a class="button" href="SELENE-V1-tailles-curseur.zip">Tailles de curseur 64 / 80 / 96</a><p class="muted">Il n'existe pas de réglage universel pour tous les joueurs. La V1 propose un point de départ lisible, avec peu d'effets sur le terrain. Pack vérifié techniquement, sans test d'import ou de gameplay en client. Les images et GIF sont des compositions/simulations hors jeu, valeurs illustratives.</p><footer>AzuRT × Codex / <a href="SELENE-V1-sources.zip">Sources modifiables</a> / <a href="https://osu.ppy.sh/users/38408224">Profil osu!</a></footer></main><script>const data=__DATA__;const frames=data.map(s=>{let i=new Image();i.src='data:image/png;base64,'+s;return i}),wave=document.getElementById('wave');let last=-1;function draw(t){let n=Math.floor(t*.06)%360;if(n!==last&&frames[n].complete){wave.src=frames[n].src;last=n}requestAnimationFrame(draw)}requestAnimationFrame(draw);let n=6,combo=document.getElementById('combo'),value=document.getElementById('value');document.getElementById('hit').onclick=()=>{n++;value.textContent=n;combo.classList.remove('pop');void combo.offsetWidth;combo.classList.add('pop')};document.getElementById('reset').onclick=()=>{n=0;value.textContent=n};</script></html>'''
    for token,val in [('__BG__',bg),('__PHOTO__',photo),('__GIF__',gif),('__SOUND__',clicks),('__DATA__',json.dumps(waves))]: html=html.replace(token,val)
    (OUT/(PREFIX+'-galerie.html')).write_text(html,encoding='utf8')

def validate():
    count=0
    for p in DEST.glob('*.png'):
        with Image.open(p) as im:
            im.load(); count+=1
            if '@2x' not in p.stem:
                with Image.open(p.with_stem(p.stem+'@2x')) as hd: assert hd.size==(2*im.width,2*im.height),p.name
    assert len([p for p in DEST.glob('scorebar-colour-*.png') if '@2x' not in p.stem])==N
    assert len([p for p in DEST.glob('hit100-*.png') if '@2x' not in p.stem])==J
    for digit in '0123456789':
        a=np.array(Image.open(DEST/f'default-{digit}.png')); yy,xx=np.where(a[:,:,3]>60)
        assert abs((xx.min()+xx.max())/2-21)<1.6 and abs((yy.min()+yy.max())/2-29)<1.6,digit
    for name in ['hit100','hit100k','hit50','hit0']:
        for i in range(J):
            a=np.array(Image.open(DEST/f'{name}-{i}.png')); yy,xx=np.where(a[:,:,3]>20)
            if len(xx): assert abs(xx-50).max()<30 and abs(yy-50).max()<30
    for p in BASE.iterdir():
        if p.name.startswith(('mania-','luminous-key-','lightingN','lightingL')): assert p.read_bytes()==(DEST/p.name).read_bytes()
    txt=(DEST/'skin.ini').read_text(encoding='utf8'); assert 'CursorExpand: 0' in txt
    assert txt.split('[Mania]',1)[1]==(BASE/'skin.ini').read_text(encoding='utf8').split('[Mania]',1)[1]
    layout=json.loads((DEST/'MainHUDComponents.json').read_text(encoding='utf8')); assert list(layout['DrawableInfo'])==['osu']
    assert any('LegacyDefaultComboCounter' in e['Type'] for e in layout['DrawableInfo']['osu'])
    for line in txt.splitlines():
        if re.match(r'(NoteImage|KeyImage|StageLeft|StageRight|StageBottom|StageLight|StageHint|LightingN|LightingL|WarningArrow|Hit[0-9])',line): assert (DEST/(line.split(':',1)[1].strip()+'.png')).exists(),line
    maxpeak=0
    for p in DEST.glob('*.wav'):
        with wave.open(str(p),'rb') as f:
            assert (f.getnchannels(),f.getsampwidth(),f.getframerate())==(1,2,48000)
            a=np.frombuffer(f.readframes(f.getnframes()),'<i2').astype(float); maxpeak=max(maxpeak,float(abs(a).max()/32767)); assert abs(a).max()<32760
    r={'release':'1.0','status':'PASS','png_files':count,'avatar_source':'https://a.ppy.sh/38408224','profile_unified':True,'combo_suffix':'Combo','native_combo_bounce':True,'yellow_per_100_supported':False,'cursor_SD':[80,80],'cursor_click_expansion':False,'cursor_options':[64,80,96],'HP_SD':[320,14],'HP_frames':N,'HP_fps':60,'judgement_frames':J,'max_WAV_peak':maxpeak,'mania_specific_assets_unchanged':True,'gameplay_tested':False}
    (ROOT/'work'/'validation-v1.json').write_text(json.dumps(r,indent=2),encoding='utf8'); return r

def main():
    DEST.mkdir(exist_ok=True)
    for p in BASE.iterdir():
        if p.is_file() and not re.match(r'(scorebar-colour-\d|hit(?:0|100k?|50)-\d|NOTES-)',p.name) and p.name not in ['FONT-CREDITS.txt','grenzegotisch-OFL.txt','unifrakturcook-OFL.txt']:
            shutil.copyfile(p,DEST/p.name)
    b.SKIN=DEST
    shapes_and_fonts(); cursor_and_options(); bounce_judgements(); profile_and_health(); ui(); config_and_layout()
    (DEST/'release.json').write_text(json.dumps({'version':'1.0','name':NAME,'theme':'cartoon competition-oriented','osu_user_id':38408224,'yellow_per_100_combo':False,'native_combo_bounce':True},indent=2))
    r=validate(); previews(); docs(r); b.pack(DEST,OUT/(NAME+'.osk'))
    with zipfile.ZipFile(OUT/(PREFIX+'-sources.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        z.write(__file__,'work/build_selene_v1.py'); z.write(ROOT/'work'/'build_selene.py','work/build_selene.py')
        z.write(AVATAR,'work/v1-assets/osu-avatar-38408224.png'); z.write(ROOT/'work'/'validation-v1.json','validation.json'); z.write(OUT/(PREFIX+'-guide.md'),'LISEZ-MOI.md')
        for p in DEST.iterdir():
            if p.is_file(): z.write(p,'work/v1-base/'+p.name)
    print(json.dumps(r),flush=True)

if __name__=='__main__': main()
