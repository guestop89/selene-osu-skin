from pathlib import Path
import sys,zipfile,shutil,json,math,base64
ROOT=Path(__file__).resolve().parent.parent
HELPER=ROOT/'work'/'update-base'/'work'
if not HELPER.exists(): HELPER=ROOT/'work'
sys.path.insert(0,str(HELPER))
import build_selene_v1 as v
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageOps
b=v.b; C=v.C
OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
SKIN=ROOT/'work'/'SELENE V1 Realease'
BASE=HELPER/'v1-base'
SKIN.mkdir(exist_ok=True)
for p in BASE.iterdir():
    if p.is_file(): shutil.copy2(p,SKIN/p.name)
b.SKIN=SKIN; v.DEST=SKIN
W,H,N=270,9,360

def notes():
    c=C(128,128);c.ellipse((5,5,123,123),(100,100,112,26),(255,255,255,190),2.7);c.save('hitcircle')
    c=C(128,128);c.ellipse((5,5,123,123),None,(255,253,255,225),2.25)
    c.ellipse((8,8,120,120),None,(255,253,255,38),.7);c.save('hitcircleoverlay')
    for src,dst in [('hitcircle','sliderstartcircle'),('hitcircleoverlay','sliderstartcircleoverlay')]:
        for suffix in ['', '@2x']:shutil.copy2(SKIN/(src+suffix+'.png'),SKIN/(dst+suffix+'.png'))
    c=C(128,128);c.ellipse((4,4,124,124),None,(255,255,255,137),1.6);c.save('approachcircle')

def cursor(size,folder):
    n=size*4;yy,xx=np.mgrid[0:n,0:n];r=np.hypot(xx-(n-1)/2,yy-(n-1)/2)/(n/2)
    core=np.exp(-(r/.265)**12); inner=np.exp(-(r/.36)**3); outer=np.exp(-(r/.59)**2)
    alpha=np.clip(core+.50*inner+.19*outer,0,1)*np.clip((1-r)/.18,0,1)
    light=np.clip(core+.37*inner,0,1)[...,None]
    rgb=np.array([149,94,225])*(1-light)+np.array([251,244,255])*light
    im=Image.fromarray(np.uint8(np.dstack([rgb,alpha*255])))
    for mult,suffix in [(1,''),(2,'@2x')]:im.resize((size*mult,size*mult),Image.Resampling.LANCZOS).save(folder/('cursor'+suffix+'.png'))

def trail():
    size=36;n=size*4;yy,xx=np.mgrid[0:n,0:n];r=np.hypot(xx-(n-1)/2,yy-(n-1)/2)/(n/2)
    core=np.exp(-(r/.29)**4);alpha=(core*.58+.24*np.exp(-(r/.58)**2))*np.clip((1-r)/.2,0,1)
    light=core[...,None];rgb=np.array([139,84,214])*(1-light)+np.array([222,201,250])*light
    im=Image.fromarray(np.uint8(np.dstack([rgb,alpha*255])))
    for mult,suffix in [(1,''),(2,'@2x')]:im.resize((size*mult,size*mult),Image.Resampling.LANCZOS).save(SKIN/('cursortrail'+suffix+'.png'))

def health():
    c=C(324,55);c.box((1,10,323,53),(12,10,18,220),(125,96,151,130),.8,r=9)
    c.box((3,13,278,29),(6,5,11,238),(151,114,170,95),.6,r=6)
    c.ellipse((11,35,19,43),(206,181,232,210));c.ellipse((14,33,21,40),(12,10,18,255))
    c.text((25,39),'Sélène',11,(216,201,231),'bold','lm')
    c.line([(72,34),(72,45)],(136,109,158,90),.6)
    for j,col in enumerate([(0,35,149),(255,255,255),(218,28,52)]):c.box((83+j*3.5,35,86+j*3.5,43),col)
    c.text((102,39),'AzuRT',13,(242,232,252),'bold','lm')
    c.text((267,39),'osu!',9,(159,138,176),'regular','rm')
    c.box((282,13,319,50),(8,6,13,255),(162,130,189,165),.8,r=6)
    photo=ImageOps.fit(Image.open(HELPER/'v1-assets'/'osu-avatar-38408224.png').convert('RGBA'),(33*b.S,33*b.S),Image.Resampling.LANCZOS)
    mask=Image.new('L',photo.size);ImageDraw.Draw(mask).rounded_rectangle((0,0,photo.width-1,photo.height-1),4*b.S,fill=255);photo.putalpha(mask);c.im.alpha_composite(photo,(284*b.S,15*b.S));c.save('scorebar-bg')
    scale=4; yy,xx=np.mgrid[0:H*scale,0:W*scale];u=xx/(W*scale-1);v_=yy/(H*scale-1)
    mask=Image.new('L',(W*scale,H*scale));ImageDraw.Draw(mask).rounded_rectangle((0,0,W*scale-1,H*scale-1),4*scale,fill=255);edge_mask=np.array(mask)/255
    base=np.array([219,134,187])*(1-u[...,None])+np.array([156,119,216])*u[...,None]
    for i in range(N):
        phase=i/N*math.tau;surface=.24+.022*np.sin(u*math.tau-phase)+.01*np.sin(u*math.tau*2+phase)
        edge=np.clip((v_-surface)*H*scale+.5,0,1)
        crest=np.exp(-((v_-surface)/.05)**2)*.28
        rgb=base+(np.array([250,226,251])-base)*crest[...,None]
        im=Image.fromarray(np.uint8(np.dstack([rgb,edge*edge_mask*220])))
        for mult,suffix in [(1,''),(2,'@2x')]:im.resize((W*mult,H*mult),Image.Resampling.LANCZOS).save(SKIN/f'scorebar-colour-{i}{suffix}.png',optimize=True)
    for suffix in ['', '@2x']:shutil.copy2(SKIN/f'scorebar-colour-0{suffix}.png',SKIN/f'scorebar-colour{suffix}.png')

def judgements():
    for name,col in [('hit100',(166,231,184)),('hit100k',(166,231,184)),('hit50',(168,202,240)),('hit0',(243,155,186))]:
        for i in range(42):
            t=i/41;alpha=round(190*min(1,t/.12)*(.5+.5*math.cos(max(0,(t-.24)/.76)*math.pi)))
            c=C(100,100)
            if name=='hit0':
                c.line([(46.5,46.5),(53.5,53.5)],(*col,alpha),1.5);c.line([(53.5,46.5),(46.5,53.5)],(*col,alpha),1.5)
            else:c.text((50,50),':3',24,(*col,alpha),'bold')
            scale=.9+.1*min(1,t/.22)+.018*math.sin(min(1,t/.25)*math.pi)
            im=c.image();small=im.resize((round(200*scale),)*2,Image.Resampling.LANCZOS);result=Image.new('RGBA',(200,200));result.alpha_composite(small,((200-small.width)//2,)*2)
            for mult,suffix in [(1,''),(2,'@2x')]:result.resize((100*mult,100*mult),Image.Resampling.LANCZOS).save(SKIN/f'{name}-{i}{suffix}.png',optimize=True)
            if i==10:
                for suffix in ['', '@2x']:shutil.copy2(SKIN/f'{name}-{i}{suffix}.png',SKIN/f'{name}{suffix}.png')

notes();cursor(88,SKIN);trail();health();judgements()
txt=(SKIN/'skin.ini').read_text(encoding='utf8').replace('CursorRotate: 1','CursorRotate: 0').replace('CursorTrailRotate: 1','CursorTrailRotate: 0')
(SKIN/'skin.ini').write_text(txt,encoding='utf8')
(SKIN/'release.json').write_text(json.dumps({'version':'1.0.1','name':'SELENE V1 Realease','changes':'HUD compact, halo violet, anneaux clairs, animations adoucies'},ensure_ascii=False,indent=2),encoding='utf8')
guide=(SKIN/'LISEZ-MOI.txt').read_text(encoding='utf8')
guide='MISE À JOUR VISUELLE 1.0.1 — nom conservé : SELENE V1 Realease\nHUD 324×55 px (au lieu de 412×79), vie 270×9 à l’origine native (5,16). Avatar 33 px, drapeau et pseudo reliés. Halo violet à cœur clair, traînée violette. Anneaux blancs plus simples, intérieur plus transparent. Jugements 24 px, alpha réduit, fondu 42 frames à 60 i/s. Boucle de vie 6 secondes à faible amplitude. Le lissage de la valeur de vie et la longueur réelle de traînée restent contrôlés par le client. Mania et sons inchangés. Vérifié techniquement, sans test de gameplay en client.\n\n'+guide
guide=guide.replace('412','324').replace('320×14','270×9').replace('de 27 px','de 24 px').replace('Curseur blanc','Curseur violet').replace('curseur blanc','curseur violet').replace('traînée blanche','traînée violette')
(SKIN/'LISEZ-MOI.txt').write_text(guide,encoding='utf8');(OUT/'SELENE-V1-guide.md').write_text(guide,encoding='utf8')
options=ROOT/'work'/'cursor-options-update';options.mkdir(exist_ok=True)
with zipfile.ZipFile(OUT/'SELENE-V1-tailles-curseur.zip','w',zipfile.ZIP_DEFLATED) as z:
    for size,label in [(64,'Compact'),(88,'Equilibre'),(96,'Large')]:
        folder=options/label;folder.mkdir(exist_ok=True);cursor(size,folder)
        for p in folder.iterdir():z.write(p,label+'/'+p.name)
    z.writestr('LISEZ-MOI.txt','Tailles facultatives du halo violet : 64, 88 (défaut), 96 px. Adapter la taille dans les options du jeu reste le plus simple. Dossiers de remplacement, pas des skins complets.')

def scene(t=0):
    im=Image.new('RGBA',(1280,720),(8,7,13))
    im.alpha_composite(b.sprite('scorebar-bg').resize((324,55)),(8,8));im.alpha_composite(b.sprite(f'scorebar-colour-{int(t*60)%360}').resize((W,H)),(13,24))
    pts=[(350,430,1,0),(520,245,2,1),(760,315,3,2)]
    for x,y,num,col in pts:
        b.paste_center(im,b.sprite('approachcircle'),(x,y),(165,165))
        a=np.array(b.sprite('hitcircle'));a[:,:,:3]=(a[:,:,:3].astype(float)*np.array(v.COLORS[col])/255).astype(np.uint8)
        b.paste_center(im,Image.fromarray(a),(x,y),(105,105));b.paste_center(im,b.sprite('hitcircleoverlay'),(x,y),(105,105));b.paste_center(im,b.sprite('default-'+str(num)),(x,y),(34,47))
    x=370+55*math.sin(t*2);y=408+25*math.cos(t*2)
    for j in range(9,0,-1):
        a=b.sprite('cursortrail').resize((36,36));a.putalpha(a.getchannel('A').point(lambda z:round(z*(1-j/10))));b.paste_center(im,a,(x-j*5,y+j*2))
    b.paste_center(im,b.sprite('cursor'),(x,y),(88,88))
    v.draw_textures(im,'438x',(28,638),'combo',.65)
    d=ImageDraw.Draw(im);font=ImageFont.truetype(str(v.COMIC),20);d.text((1040,20),'99.42 %',font=font,fill=(229,217,241))
    return im

canvas=C(1440,1000,(8,7,13,255));canvas.text((55,65),'Sélène · V1 Realease',31,(240,227,250),'bold','lm');canvas.text((55,116),'Halo violet. HUD compact. Repères clairs.',23,(184,157,206),'regular','lm')
preview=canvas.image().resize((1440,1000));preview.alpha_composite(scene().resize((1280,720)),(55,170))
ImageDraw.Draw(preview).text((55,945),'Aperçu composé hors jeu · mise à jour visuelle 1.0.1 · valeurs illustratives',font=ImageFont.truetype(str(v.COMIC),15),fill=(143,125,158))
preview.convert('RGB').save(OUT/'SELENE-V1-apercu.jpg',quality=95)
frames=[]
for i in range(150):
    im=scene(i/25).resize((760,428),Image.Resampling.LANCZOS);frames.append(im.convert('RGB'))
frames[0].save(OUT/'SELENE-V1-mouvement.gif',save_all=True,append_images=frames[1:],duration=40,loop=0)
for p in SKIN.glob('*.png'):
    if '@2x' not in p.stem:
        with Image.open(p) as im,Image.open(p.with_stem(p.stem+'@2x')) as hd:assert hd.size==(im.width*2,im.height*2),p
for p in BASE.iterdir():
    if p.name.startswith(('mania-','luminous-key-','lightingN','lightingL')):assert p.read_bytes()==(SKIN/p.name).read_bytes()
with zipfile.ZipFile(OUT/'SELENE V1 Realease.osk','w',zipfile.ZIP_DEFLATED) as z:
    for p in SKIN.iterdir():
        if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(OUT/'SELENE V1 Realease.osk') as z:assert z.testzip() is None
with zipfile.ZipFile(OUT/'SELENE-V1-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(__file__,'work/refresh_selene.py')
    for name in ['build_selene.py','build_selene_v1.py']:z.write(HELPER/name,'work/'+name)
    z.write(HELPER/'v1-assets/osu-avatar-38408224.png','work/v1-assets/osu-avatar-38408224.png')
    for p in SKIN.iterdir():
        if p.is_file():z.write(p,'work/v1-base/'+p.name)
print('PASS — 1.0.1, SD/HD, archive, mania preserved',flush=True)

