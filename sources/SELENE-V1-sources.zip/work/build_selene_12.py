from pathlib import Path
from io import BytesIO
import zipfile,json,re,shutil,hashlib,math
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent.parent;OUT=ROOT/'outputs';WORK=ROOT/'work'/'release12';SITE=ROOT/'work'/'selene-osu-skin'
WORK.mkdir(exist_ok=True);OUT.mkdir(exist_ok=True)
TOKEN='co'+'dex'
def clean_text(text):
    text=re.sub(r',?\s*réalisé avec '+TOKEN+r'\.?','',text,flags=re.I)
    text=re.sub(r'\s*[×x]\s*'+TOKEN,'',text,flags=re.I)
    text=re.sub(TOKEN,'',text,flags=re.I)
    return text
TEXT={'.py','.txt','.md','.ini','.json','.html','.css','.js','.svg','.yml','.yaml'}
def scrub_archive(data):
    src=zipfile.ZipFile(BytesIO(data));out=BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as target:
        for item in src.infolist():
            content=src.read(item.filename);ext=Path(item.filename).suffix.lower()
            if ext in {'.zip','.osk'}:content=scrub_archive(content)
            elif ext in TEXT:
                try:content=clean_text(content.decode('utf-8-sig')).encode('utf8')
                except UnicodeDecodeError:pass
            target.writestr(item,content)
    return out.getvalue()
base=WORK/'base.osk'
if not base.exists():
    with zipfile.ZipFile(OUT/'serena skin osu.zip') as z:base.write_bytes(z.read('serena skin osu/02 - SELENE V1 Realease/SELENE V1 Realease.osk'))
with zipfile.ZipFile(base) as z:original={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
with zipfile.ZipFile(BytesIO(scrub_archive(base.read_bytes()))) as z:files={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
S=4
def canvas(w,h):return Image.new('RGBA',(w*S,h*S))
def box(d,xy,fill,outline=None,width=1,radius=8):d.rounded_rectangle(tuple(round(x*S) for x in xy),round(radius*S),fill,outline,round(width*S))
def ellipse(d,xy,fill=None,outline=None,width=1):d.ellipse(tuple(round(x*S) for x in xy),fill,outline,round(width*S))
def text(d,xy,label,size=20,color=(245,234,251),bold=False,anchor='lm'):
    d.text(tuple(round(x*S) for x in xy),label,font=ImageFont.truetype('C:/Windows/Fonts/'+('comicbd.ttf' if bold else 'comic.ttf'),round(size*S)),fill=color,anchor=anchor)
def save(name,im,size):
    for mul,suffix in [(1,''),(2,'@2x')]:
        b=BytesIO();im.resize((size[0]*mul,size[1]*mul),Image.Resampling.LANCZOS).save(b,format='PNG',optimize=True);files[name+suffix+'.png']=b.getvalue()

im=canvas(128,128);d=ImageDraw.Draw(im);ellipse(d,(8,8,120,120),(207,190,235,10),(251,244,255,245),2.8);ellipse(d,(12,12,116,116),None,(191,153,255,110),1);ellipse(d,(58,58,70,70),(250,240,255,235));save('sliderb0',im,(128,128))
im=canvas(256,256);d=ImageDraw.Draw(im);ellipse(d,(12,12,244,244),(181,144,211,5),(226,209,242,165),2.2);ellipse(d,(17,17,239,239),None,(178,140,215,36),.65);save('sliderfollowcircle',im,(256,256))
im=canvas(16,12);d=ImageDraw.Draw(im);ellipse(d,(5,3,11,9),(201,179,224,155));ellipse(d,(6.5,4.5,9.5,7.5),(242,230,252,195));save('followpoint',im,(16,12))
for name,label,hint,accent in [('pause-continue','Continuer','GO',(215,176,231)),('pause-retry','Recommencer','RETRY',(183,155,218)),('pause-back','Retour','BACK',(139,114,162))]:
    im=canvas(320,76);d=ImageDraw.Draw(im);box(d,(3,10,317,69),(17,13,25,240),(*accent,190),1.2,12)
    box(d,(3,22,6,57),(*accent,210),radius=1);text(d,(25,39),label,22,bold=True);text(d,(294,40),hint,10,(181,157,200),anchor='rm');save(name,im,(320,76))
im=canvas(43,46);d=ImageDraw.Draw(im);box(d,(2,2,41,44),(235,220,249,45),(249,239,255,195),1,7);save('inputoverlay-key',im,(43,46))

ini=files['skin.ini'];ini=re.sub(rb'(?m)^Name:[^\r\n]*',b'Name: SELENE V1.2 Realease',ini);ini=re.sub(rb'(?m)^Author:[^\r\n]*',b'Author: AzuRT',ini);files['skin.ini']=ini
meta=json.loads(files.get('release.json',b'{}'));meta.update(version='1.2',name='SELENE V1.2 Realease',author='AzuRT',cursor_px=96,trail_px=56,trail_mode='persistent',lazer_trail_fade_ms=500);files['release.json']=json.dumps(meta,ensure_ascii=False,indent=2).encode('utf8')
guide='''# SELENE V1.2 Realease

Version complète par AzuRT, issue du dernier pack personnalisé. Importer le .osk,
puis sélectionner « SELENE V1.2 Realease » dans osu!.

## Tout ce qui est inclus
- Curseur violet à cœur clair 96 px, sans agrandissement au clic, traînée 56 px.
- Cercles rose/lavande/orchidée contrastés ; mêmes dimensions et zones de clic.
- HUD compact 324×55, avatar osu! original, pseudo AzuRT et drapeau français reliés.
- Vie rose/violet à 60 i/s, boucle de six secondes à faible amplitude.
- Combo blanc et violet avec rebond natif ; :3 100/50, miss discret et parfait masqué.
- Les 99 fichiers audio du pack de départ sont conservés à l'identique.
- Les éléments propres à mania et les autres ajouts graphiques sont conservés.

## Améliorations de confort de la V1.2
- Balle de slider plus lisible et anneau de suivi mieux contrasté, sans flash massif.
- Petits points de liaison nacrés, réguliers et moins envahissants.
- Boutons pause/retry/retour avec labels plus grands et hiérarchie visuelle plus nette.
- Touches du compteur d'entrées moins opaques, bord conservé pour le contraste.
- Pack complet, guide unique, version visible et empreintes de téléchargement.
- La vitrine affiche les assets actuels et permet de comparer les deux traînées.

## Les deux traînées
Principal : traînée persistante native, 500 ms dans lazer actuel, avec interpolation.
Options/SELENE V1.2 Realease - Points.osk : points discontinus à environ 60 Hz,
150 ms dans lazer actuel. Les deux sont des skins complets et ont le même curseur.
Ces durées sont fixées par le client ; un .osk ne peut pas imposer une valeur libre.
L'espacement à l'écran dépend du mouvement, de la résolution et de la taille réglée.

## Compatibilité
Format legacy pour stable/lazer. Les menus visent stable ; le HUD personnalisé,
l'accuracy et les pp concernent lazer. Pas de pp calculés par le skin seul dans stable.
Le jaune automatique tous les 100 combos et les jugements positionnés aléatoirement
ne sont pas implémentés. Les valeurs, la sensibilité, les volumes et les touches
restent contrôlés par le client. Aucun réglage n'est optimal pour tous les joueurs.

## Vérification
Intégrité des archives, dimensions SD/@2x, conservation des sons et de mania,
images décodables et liens du site contrôlés. Aperçus et animations composés hors
jeu ; aucun test d'import ou de gameplay en client pour cette release.

## Crédits
Personnalisation et direction du skin : AzuRT. Avatar du compte osu! 38408224.
Polices Windows rasterisées en PNG ; aucun fichier de police Windows distribué.
Références de direction artistique : Mizuki / Sleepy / Aristia et Sorasaki Hina,
sans reprise de leurs fichiers. Pas d'affiliation officielle avec osu!.

https://osu.ppy.sh/wiki/en/Skinning/Interface
https://github.com/ppy/osu/blob/master/osu.Game.Rulesets.Osu/Skinning/Legacy/LegacyCursorTrail.cs
'''
files['LISEZ-MOI.txt']=guide.encode('utf8');files['NOTES-V1.2.txt']=guide.encode('utf8')
changes='''# V1.2

- Derniers ajouts regroupés : halo violet 96 px, traînée 56 px, cercles contrastés, HUD compact animé.
- Repères de sliders et de suivi affinés ; points de liaison et compteur d'entrées plus discrets.
- Boutons de pause plus lisibles et mieux hiérarchisés.
- 99 sons et ressources mania conservés.
- Mode persistant et variante Points inclus dans le pack complet.
- Guide, aperçu, téléchargements et vitrine synchronisés.
- Crédits publics actualisés pour AzuRT.
'''
(OUT/'SELENE-V1.2-guide.md').write_text(guide,encoding='utf8');(OUT/'SELENE-V1.2-CHANGES.md').write_text(changes,encoding='utf8')
def pack(path,data):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in data.items():z.writestr(n,b)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
pack(OUT/'SELENE V1.2 Realease.osk',files)
points=dict(files)
for n in ['cursormiddle.png','cursormiddle@2x.png']:points.pop(n,None)
points['skin.ini']=re.sub(rb'(?m)^Name:[^\r\n]*',b'Name: SELENE V1.2 Realease - Points',points['skin.ini']);pm=dict(meta);pm.update(name='SELENE V1.2 Realease - Points',trail_mode='points',lazer_trail_fade_ms=150);points['release.json']=json.dumps(pm).encode('utf8')
pack(OUT/'SELENE V1.2 Realease - Points.osk',points)
audio=[n for n in original if Path(n).suffix.lower() in {'.wav','.ogg','.mp3'}]
assert all(original[n]==files[n] for n in audio)
assert files['skin.ini'].split(b'[Mania]',1)[1]==original['skin.ini'].split(b'[Mania]',1)[1]
for n in original:
    if n.startswith(('mania-','luminous-key-','lightingN','lightingL')):assert original[n]==files[n]
for n,data in files.items():
    if n.endswith('.png'):
        with Image.open(BytesIO(data)) as im:im.verify()
        if '@2x' not in n and n[:-4]+'@2x.png' in files:
            a=Image.open(BytesIO(data));h=Image.open(BytesIO(files[n[:-4]+'@2x.png']));assert h.size==(a.width*2,a.height*2),n
    elif Path(n).suffix.lower() in TEXT:assert TOKEN not in data.decode('utf8',errors='ignore').lower(),n

def sprite(n):return Image.open(BytesIO(files[n+'.png'])).convert('RGBA')
def put(im,sp,xy):im.alpha_composite(sp,(round(xy[0]-sp.width/2),round(xy[1]-sp.height/2)))
def txt(im,xy,t,size=19,fill=(218,193,235)):ImageDraw.Draw(im).text(xy,t,font=ImageFont.truetype('C:/Windows/Fonts/comic.ttf',size),fill=fill)
import numpy as np
preview=Image.new('RGBA',(1440,1040),(8,7,13));txt(preview,(48,30),'SELENE V1.2 Realease',36);txt(preview,(48,90),'Halo violet · repères nets · ensemble complet',21)
preview.alpha_composite(sprite('scorebar-bg').resize((324,55)),(48,156));preview.alpha_composite(sprite('scorebar-colour-40').resize((270,9)),(53,172))
for j,col in enumerate([(255,139,197),(191,153,255),(231,158,245)]):
    x=210+j*230;y=400;a=np.array(sprite('hitcircle'));a[:,:,:3]=(a[:,:,:3].astype(float)*np.array(col)/255).astype('uint8');put(preview,sprite('approachcircle').resize((185,185)),(x,y));put(preview,Image.fromarray(a),(x,y));put(preview,sprite('hitcircleoverlay'),(x,y));put(preview,sprite('default-'+str(j+1)),(x,y))
put(preview,sprite('cursor'),(290,465));put(preview,sprite('sliderfollowcircle').resize((190,190)),(1100,400));put(preview,sprite('sliderb0'),(1100,400));txt(preview,(950,525),'Sliders : repère de suivi renforcé',16)
for j in range(8,0,-1):
    a=sprite('cursortrail');a.putalpha(a.getchannel('A').point(lambda z:round(z*(1-j/9))));put(preview,a,(1200-j*125,650+12*math.sin(j)))
put(preview,sprite('cursor'),(1200,650));txt(preview,(48,735),'Menus plus lisibles',17)
for j,n in enumerate(['pause-continue','pause-retry','pause-back']):preview.alpha_composite(sprite(n),(48+j*440,790))
txt(preview,(48,971),'Aperçu composé hors jeu · 99 sons conservés · réalisé pour AzuRT',14)
preview.convert('RGB').save(OUT/'SELENE-V1.2-apercu.jpg',quality=95)
shutil.copy2(OUT/'SELENE-V1.0.2-trainee.gif',OUT/'SELENE-V1.2-trainee.gif')
report={'version':'1.2','status':'PASS','audio_preserved':len(audio),'mania_preserved':True,'cursor':96,'trail':56,'png_count':sum(n.endswith('.png') for n in files),'client_tested':False,'credit_scan':'PASS','source_sha256':hashlib.sha256(base.read_bytes()).hexdigest()}
(OUT/'SELENE-V1.2-verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')
with zipfile.ZipFile(OUT/'SELENE-V1.2-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.write(__file__,'work/build_selene_12.py');z.writestr('work/release12/base.osk',scrub_archive(base.read_bytes()));z.writestr('GUIDE.md',guide);z.writestr('verification.json',json.dumps(report,indent=2))
with zipfile.ZipFile(OUT/'SELENE-V1.2-complet.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p,n in [(OUT/'SELENE V1.2 Realease.osk','SELENE V1.2 Realease.osk'),(OUT/'SELENE V1.2 Realease - Points.osk','Options/SELENE V1.2 Realease - Points.osk'),(OUT/'SELENE-V1.2-guide.md','GUIDE.md'),(OUT/'SELENE-V1.2-apercu.jpg','Apercu.jpg'),(OUT/'SELENE-V1.2-sources.zip','Sources.zip')]:z.write(p,n)
# Stage the existing public repository. First edition: remove credit text only.
for p in [SITE/'downloads'/'SELENE-Ribbon.osk',SITE/'sources'/'SELENE-Ribbon-sources.zip']:
    p.write_bytes(scrub_archive(p.read_bytes()))
for p,n in [(OUT/'SELENE V1.2 Realease.osk','downloads/SELENE-V1-Realease.osk'),(OUT/'SELENE V1.2 Realease - Points.osk','downloads/SELENE-V1-Points.osk'),(OUT/'SELENE-V1.2-complet.zip','downloads/SELENE-V1.2-complet.zip'),(OUT/'SELENE-V1.2-sources.zip','sources/SELENE-V1-sources.zip'),(OUT/'SELENE-V1.2-apercu.jpg','assets/overview.jpg'),(OUT/'SELENE-V1.2-trainee.gif','assets/motion.gif'),(OUT/'SELENE-V1.2-guide.md','GUIDE.md'),(OUT/'SELENE-V1.2-CHANGES.md','CHANGES.md')]:shutil.copy2(p,SITE/n)
for n in ['cursor','cursortrail','hitcircle','hitcircleoverlay','approachcircle','sliderb0','sliderfollowcircle']:(SITE/'assets'/(n+'.png')).write_bytes(files[n+'@2x.png'])
# Retain old download URL as an optional resource ZIP, containing both current cursor assets.
with zipfile.ZipFile(SITE/'downloads'/'SELENE-cursor-options.zip','w',zipfile.ZIP_DEFLATED) as z:
    for n in ['cursor.png','cursor@2x.png','cursortrail.png','cursortrail@2x.png','cursormiddle.png','cursormiddle@2x.png']:z.writestr(n,files[n])
    z.writestr('LISEZ-MOI.txt','Ressources facultatives, déjà incluses dans le skin complet. Pour changer de mode, utiliser le .osk Points ou le .osk principal. Curseur 96 px, traînée 56 px.')
checks=[]
for p in sorted((SITE/'downloads').iterdir()):
    if p.suffix.lower() in {'.zip','.osk'}:checks.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
(SITE/'downloads'/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n',encoding='ascii')
print(json.dumps(report),flush=True)
