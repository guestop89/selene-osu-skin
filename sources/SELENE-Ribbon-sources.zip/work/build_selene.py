"""SELENE / ribbon edition. Original procedural osu! legacy skin.
Build: Python 3.12+, Pillow, numpy. No downloaded artwork, samples or fonts.
Windows system fonts are rasterised locally and never redistributed.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import math, wave, zipfile, json, base64, hashlib, re, shutil

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs'
SKIN = ROOT / 'work' / 'SELENE - Ribbon'
OUT.mkdir(exist_ok=True); SKIN.mkdir(exist_ok=True)
INK = (12,14,21); PANEL = (24,26,37); LINE = (60,61,78)
WHITE = (245,242,248); ROSE = (242,180,205); LILAC = (193,185,244)
MINT = (160,239,222); GOLD = (248,218,151); RED = (250,122,148)
MUTED = (143,143,164)
FONTDIR = Path('C:/Windows/Fonts')
FONT = {'regular':'segoeui.ttf','light':'segoeuil.ttf','bold':'segoeuib.ttf','mono':'consola.ttf'}
S = 3

def font(size,style='regular'):
    return ImageFont.truetype(str(FONTDIR/FONT[style]), max(1,round(size*S)))

class Canvas:
    def __init__(self,w,h,bg=(0,0,0,0)):
        self.w,self.h = w,h
        self.im = Image.new('RGBA',(round(w*S),round(h*S)),bg)
        self.d = ImageDraw.Draw(self.im)
    def box(self,xy,fill=None,outline=None,width=1,r=0):
        xy=tuple(round(v*S) for v in xy)
        if r: self.d.rounded_rectangle(xy,round(r*S),fill,outline,round(width*S))
        else: self.d.rectangle(xy,fill,outline,round(width*S))
    def ellipse(self,xy,fill=None,outline=None,width=1):
        self.d.ellipse(tuple(round(v*S) for v in xy),fill,outline,round(width*S))
    def line(self,pts,fill,width=1):
        self.d.line([(round(x*S),round(y*S)) for x,y in pts],fill,width=max(1,round(width*S)),joint='curve')
    def poly(self,pts,fill):
        self.d.polygon([(round(x*S),round(y*S)) for x,y in pts],fill)
    def text(self,xy,t,size=20,fill=WHITE,style='regular',anchor='mm'):
        self.d.text(tuple(round(v*S) for v in xy),t,font=font(size,style),fill=fill,anchor=anchor,stroke_width=0)
    def bezier(self,p,color,width=1):
        pts=[]
        for t in np.linspace(0,1,200):
            q=(1-t)**3*np.array(p[0])+3*(1-t)**2*t*np.array(p[1])+3*(1-t)*t*t*np.array(p[2])+t**3*np.array(p[3])
            pts.append(tuple(q))
        self.line(pts,color,width)
    def image(self):
        return self.im.resize((self.w*2,self.h*2),Image.Resampling.LANCZOS)
    def save(self,name,hd=True):
        im=self.image()
        im.resize((self.w,self.h),Image.Resampling.LANCZOS).save(SKIN/f'{name}.png',optimize=True)
        if hd: im.save(SKIN/f'{name}@2x.png',optimize=True)
        return im

def empty(name):
    Image.new('RGBA',(1,1)).save(SKIN/f'{name}.png')
    Image.new('RGBA',(2,2)).save(SKIN/f'{name}@2x.png')

def ribbon(c,x,y,sz=30,color=ROSE):
    # A single continuous crossed ribbon, deliberately asymmetrical.
    c.bezier([(x,y),(x-sz*.95,y-sz*.9),(x-sz*1.3,y+sz*.6),(x,y)],color,sz*.10)
    c.bezier([(x,y),(x+sz*1.3,y-sz*.75),(x+sz*.85,y+sz*.8),(x,y)],color,sz*.10)
    c.line([(x,y),(x-sz*.48,y+sz*.95)],color,sz*.10)
    c.line([(x,y),(x+sz*.74,y+sz*.78)],color,sz*.10)
    c.ellipse((x-sz*.09,y-sz*.09,x+sz*.09,y+sz*.09),color)

def ring_asset(name,size,radius,width,color,fill=None):
    c=Canvas(size,size); mid=size/2
    c.ellipse((mid-radius,mid-radius,mid+radius,mid+radius),fill,color,width)
    return c.save(name)

def pill(name,label,w=320,h=76,accent=ROSE,sub=None):
    c=Canvas(w,h)
    c.box((3,3,w-3,h-3),(*PANEL,245),(*LINE,220),1,r=10)
    c.box((3,20,6,h-20),accent,r=1)
    c.text((29,h/2),label,22,WHITE,'regular','lm')
    if sub: c.text((w-22,h/2),sub,11,accent,'mono','rm')
    return c.save(name)

def label(name,text,size=25,color=WHITE,w=150,h=56,style='regular'):
    c=Canvas(w,h); c.text((w/2,h/2),text,size,color,style); return c.save(name)

def build_standard():
    # Gameplay circles: neutral multiplication base, permanent white edge overlay.
    c=Canvas(128,128)
    c.ellipse((5,5,123,123),(20,21,28,246),(255,255,255,255),3)
    c.ellipse((10,10,118,118),None,(170,170,178,210),.8)
    c.save('hitcircle')
    c=Canvas(128,128)
    c.ellipse((5,5,123,123),None,(*WHITE,255),1.5)
    c.ellipse((9,9,119,119),None,(*WHITE,85),.65)
    c.save('hitcircleoverlay')
    for a,b in [('hitcircle','sliderstartcircle'),('hitcircleoverlay','sliderstartcircleoverlay')]:
        for suffix in ['', '@2x']: shutil.copyfile(SKIN/f'{a}{suffix}.png',SKIN/f'{b}{suffix}.png')
    empty('sliderendcircle'); empty('sliderendcircleoverlay')
    ring_asset('approachcircle',128,60,2.1,(255,255,255,235))
    c=Canvas(128,128); c.ellipse((8,8,120,120),(245,242,248,18),WHITE,2.7)
    c.ellipse((56,56,72,72),ROSE); c.save('sliderb0')
    empty('sliderb-nd'); empty('sliderb-spec')
    ring_asset('sliderfollowcircle',256,116,2.5,(*WHITE,170),(*LILAC,12))
    c=Canvas(16,16); c.ellipse((4,4,12,12),WHITE); c.save('sliderscorepoint')
    c=Canvas(40,40); c.line([(15,9),(26,20),(15,31)],WHITE,4); c.line([(7,9),(18,20),(7,31)],WHITE,2); c.save('reversearrow')
    c=Canvas(16,12); c.box((5,4,11,8),(*WHITE,155),r=2); c.save('followpoint')
    # No expanding cursor. Mint is deliberately distinct from combo colours.
    c=Canvas(32,32); c.ellipse((3,3,29,29),(*INK,255),(*MINT,255),2.6)
    c.ellipse((8,8,24,24),(*MINT,255)); c.ellipse((13.2,13.2,18.8,18.8),WHITE); c.save('cursor')
    c=Canvas(10,10); c.ellipse((2,2,8,8),(*MINT,130)); c.save('cursortrail')
    # Omit cursormiddle: that file changes trail behaviour in the client.
    c=Canvas(16,16); c.ellipse((5,5,11,11),(*ROSE,75)); c.save('cursor-smoke')
    for n in ['cursor-ripple','lighting','comboburst','comboburst-mania','comboburst-fruits','star2']:
        empty(n)
    for n in ['hit300','hit300k','hit300g']: empty(n)
    for n,t,col in [('hit100','100',LILAC),('hit100k','100',LILAC),('hit50','50',GOLD),('hit0','×',RED)]:
        label(n,t,25,col,90,44,'bold')
    # Fonts are fixed-width within each prefix. Conservative overlap for 2+ digits.
    for prefix,w,h,fs,sty in [('default',40,56,42,'regular'),('score',29,42,34,'light'),('combo',28,42,34,'light'),('scoreentry',12,18,14,'regular')]:
        for ch in '0123456789': label(f'{prefix}-{ch}',ch,fs,WHITE,w,h,sty)
    for prefix,w,h,fs in [('score',29,42,34),('combo',28,42,34),('scoreentry',12,18,14)]:
        for name,ch,ww in [('dot','.',max(6,w//2)),('comma',',',max(6,w//2)),('percent','%',w+8),('x','x',w-3)]:
            label(f'{prefix}-{name}',ch,fs,WHITE,ww,h,'light')
    # Spinner keeps orientation feedback, removes the flash and large decoration.
    ring_asset('spinner-bottom',512,218,1.5,(*LILAC,90))
    c=Canvas(512,512)
    for i in range(48):
        a=i*math.tau/48
        r=207 if i%4==0 else 215
        c.line([(256+r*math.cos(a),256+r*math.sin(a)),(256+224*math.cos(a),256+224*math.sin(a))],(*WHITE,120),1.1)
    c.save('spinner-top')
    c=Canvas(128,128); ribbon(c,64,55,25); c.line([(64,15),(64,30)],MINT,3); c.save('spinner-middle')
    for n in ['spinner-middle2','spinner-glow','spinner-metre','spinner-background']: empty(n)
    ring_asset('spinner-circle',512,218,2,WHITE)
    ring_asset('spinner-approachcircle',512,245,2,ROSE)
    label('spinner-spin','SPIN',24,WHITE,220,70,'light')
    label('spinner-clear','CLEAR',26,MINT,220,70,'light')
    label('spinner-warning','SPIN',24,WHITE,220,70,'light')
    label('ready','READY',38,LILAC,300,90,'light'); label('go','GO',46,MINT,220,90,'light')
    for i in [1,2,3]: label(f'count{i}',str(i),54,WHITE,110,100,'light')

def build_interface():
    # Health bar: restrained geometry only; compatible with mania rotation.
    c=Canvas(340,34); c.box((4,15,329,25),(34,36,48,220),r=4); c.save('scorebar-bg')
    c=Canvas(320,8); c.box((0,0,319,7),ROSE,r=3); c.save('scorebar-colour')
    for n in ['scorebar-ki','scorebar-kidanger','scorebar-kidanger2']: empty(n)
    c=Canvas(193,55); c.box((2,2,191,53),(*INK,120),(*LINE,140),r=7); c.save('inputoverlay-background')
    c=Canvas(43,46); c.box((2,2,41,44),(255,255,255,115),WHITE,1,r=6); c.save('inputoverlay-key')
    for name,lab,sub,col in [('pause-continue','Continue','RESUME',MINT),('pause-retry','Recommencer','RETRY',LILAC),('pause-back','Retour','EXIT',ROSE),('pause-replay','Revoir','REPLAY',ROSE)]:
        pill(name,lab,320,76,col,sub)
    for name,title,sub in [('pause-overlay','take a breath.','S E L E N E  /  R I B B O N'),('fail-background','one more try.','S E L E N E  /  R I B B O N')]:
        c=Canvas(1366,768,(8,10,17,205)); ribbon(c,683,73,18)
        c.text((683,130),title,32,WHITE,'light'); c.text((683,700),sub,11,MUTED,'mono'); c.save(name)
    # Actual legacy slots and sizes; no baked fake hitboxes or displaced labels.
    for name,txt,key,w in [('mode','MODE','F1',92),('mods','MODS','F2',77),('random','RANDOM','F3',77),('options','OPTIONS','F4',77)]:
        for over in [False,True]:
            c=Canvas(w,90); col=ROSE if over else LILAC
            c.box((3,9,w-3,88),(*PANEL,250),col if over else LINE,1,r=8)
            c.line([(14,15),(w-14,15)],col,2)
            # mode-small icon is client-positioned; leave its upper slot clear.
            if name!='mode':
                c.text((w/2,38),key,15,col,'mono')
            c.text((w/2,70),txt,10,WHITE,'bold'); c.save('selection-'+name+('-over' if over else ''))
    c=Canvas(200,96); c.box((0,9,193,95),(*PANEL,250),LINE,r=10)
    c.line([(22,48),(12,59),(22,70)],ROSE,2.5); c.text((43,59),'RETOUR',16,WHITE,'regular','lm'); ribbon(c,165,55,13); c.save('menu-back')
    c=Canvas(700,90); c.box((2,3,699,87),(225,225,230,235),(255,255,255,225),1,r=6)
    c.box((2,15,7,75),(255,255,255,255),r=1); c.save('menu-button-background')
    c=Canvas(180,40); c.box((1,1,179,39),(255,255,255,130),r=5); c.save('selection-tab')
    c=Canvas(450,110); c.box((8,8,442,102),(*PANEL,248),LINE,r=12)
    c.text((34,55),'PLAY',34,WHITE,'light','lm'); ribbon(c,375,48,24); c.save('menu-button-background-active')
    pill('play-skip','Passer',180,60,MINT,'SKIP')
    # Generic three-piece buttons keep white tintable faces.
    for name,w in [('button-left',8),('button-middle',8),('button-right',8)]:
        c=Canvas(w,42); c.box((0,1,w-1,40),(235,235,240,230),r=2 if name!='button-middle' else 0); c.save(name)
    for name,txt in [('section-pass','nice rhythm.'),('section-fail','refocus.')]: label(name,txt,28,MINT if name.endswith('pass') else ROSE,320,75,'light')
    for name,sz in [('arrow-generic',32),('arrow-warning',32),('arrow-pause',32),('play-warningarrow',32),('mania-warningarrow',32)]:
        c=Canvas(sz,sz); c.line([(8,9),(16,21),(24,9)],WHITE,2.6); c.save(name)
    for mode in ['osu','taiko','fruits','mania']:
        for suffix,size in [('',256),('-med',128),('-small',32)]:
            c=Canvas(size,size); cx=size/2; r=size*.31; col=(*WHITE,65) if suffix=='' else WHITE
            if mode=='osu':
                c.ellipse((cx-r,cx-r,cx+r,cx+r),None,col,max(1,size*.024))
                c.ellipse((cx-r*.45,cx-r*.45,cx+r*.45,cx+r*.45),None,col,max(1,size*.017))
            elif mode=='mania':
                for j in range(4):
                    x=size*(.24+j*.15); c.box((x,size*.27,x+size*.08,size*.73),col,r=max(1,size*.014))
            elif mode=='taiko':
                c.ellipse((cx-r,cx-r,cx+r,cx+r),None,col,max(1,size*.024)); c.line([(cx,cx-r),(cx,cx+r)],col,max(1,size*.02))
            else:
                c.line([(size*.19,size*.53),(size*.32,size*.75),(size*.68,size*.75),(size*.81,size*.53)],col,max(1,size*.025))
                for j in [-1,1]: c.ellipse((cx+j*r*.5-r*.25,size*.24,cx+j*r*.5+r*.25,size*.24+r*.5),col)
            c.save('mode-'+mode+suffix)
    # Thin scorecard; the game continues drawing its native score labels/numbers.
    c=Canvas(660,530); c.box((9,8,650,520),(*INK,205),(*LINE,170),r=12)
    c.line([(28,10),(628,10)],(*ROSE,160),1.6); c.save('ranking-panel')
    c=Canvas(308,148); c.box((1,1,307,147),(*INK,200),LINE,r=7)
    for y in [38,74,110]: c.line([(10,y),(298,y)],(*LINE,90),.5)
    c.save('ranking-graph')
    for name,t in [('ranking-title','SESSION / COMPLETE'),('ranking-accuracy','ACCURACY'),('ranking-maxcombo','MAX COMBO'),('ranking-perfect','FULL COMBO')]:
        label(name,t,18,MINT if name=='ranking-perfect' else WHITE,330,52,'light')
    for grade,col in [('X',GOLD),('XH',WHITE),('S',ROSE),('SH',WHITE),('A',MINT),('B',LILAC),('C',GOLD),('D',RED)]:
        disp='SS' if grade.startswith('X') else grade[0]
        for small in [False,True]:
            w,h=(42,30) if small else (240,160)
            c=Canvas(w,h); c.text((w/2,h/2),disp,24 if small else 114,col,'light')
            if not small: c.line([(w*.28,h*.89),(w*.72,h*.89)],col,1)
            c.save('ranking-'+grade+('-small' if small else ''))
    mods={'easy':'EZ','nofail':'NF','halftime':'HT','hardrock':'HR','suddendeath':'SD','perfect':'PF','doubletime':'DT','nightcore':'NC','hidden':'HD','flashlight':'FL','relax':'RX','relax2':'AP','spunout':'SO','autoplay':'AT','cinema':'CN','target':'TP','scorev2':'V2','mirror':'MR','random':'RD','keycoop':'CO'}
    mods.update({f'key{i}':f'{i}K' for i in range(1,10)})
    for name,t in mods.items():
        c=Canvas(68,58); c.box((2,2,66,56),(*PANEL,245),LINE,r=8)
        col=MINT if name in ['easy','nofail','halftime'] else ROSE if name in ['hardrock','doubletime','nightcore','hidden','flashlight'] else LILAC
        c.text((34,27),t,22,col,'light'); c.line([(21,47),(47,47)],col,1.5); c.save('selection-mod-'+name)
    # A familiar star rather than a default glitter particle.
    c=Canvas(48,48); pts=[]
    for j in range(10):
        a=-math.pi/2+j*math.pi/5; rr=19 if j%2==0 else 8
        pts.append((24+rr*math.cos(a),24+rr*math.sin(a)))
    c.poly(pts,WHITE); c.save('star')

def build_background():
    w,h=1920,1080
    yy,xx=np.mgrid[0:h,0:w]
    a=np.zeros((h,w,3),dtype=float)+np.array(INK)
    for x,y,rad,col,power in [(1620,230,720,ROSE,.075),(1020,900,800,LILAC,.05),(0,0,650,MINT,.022)]:
        g=np.exp(-((xx-x)**2+(yy-y)**2)/(2*rad**2))*power
        a+=g[:,:,None]*np.array(col)
    im=Image.fromarray(np.uint8(np.clip(a,0,255)),'RGB').convert('RGBA')
    c=Canvas(w,h); c.im=im.resize((w*S,h*S),Image.Resampling.BICUBIC); c.d=ImageDraw.Draw(c.im)
    for j in range(11):
        c.bezier([(960+j*6,1150),(1780+j*4,680),(760+j*5,-150),(1980+j*12,160)],(*ROSE,40+j*3),.8 if j%3 else 1.3)
    c.bezier([(1050,1150),(1900,430),(1110,-80),(1980,170)],(*LILAC,110),2)
    for x,y in [(1440,230),(1740,700),(1170,850)]:
        c.line([(x-5,y),(x+5,y)],(*WHITE,80),.7); c.line([(x,y-5),(x,y+5)],(*WHITE,80),.7)
    ribbon(c,130,120,25)
    c.text((90,915),'S É L È N E',40,WHITE,'light','lm')
    c.text((94,965),'R I B B O N   E D I T I O N   /   0 1',12,MUTED,'mono','lm')
    c.im.resize((w,h),Image.Resampling.LANCZOS).convert('RGB').save(SKIN/'menu-background.jpg',quality=95,subsampling=0)

PATTERNS={1:'S',2:'11',3:'1S1',4:'1221',5:'12S21',6:'121121',7:'121S121',8:'12122121',9:'1212S2121',10:'1212112121',12:'121121121121',14:'121S121121S121',16:'1212212112122121',18:'1212S21211212S2121'}
WIDTHS={1:64,2:56,3:50,4:46,5:44,6:42,7:40,8:36,9:34,10:32,12:28,14:26,16:24,18:22}

def build_mania():
    for kind,col in [('1',WHITE),('2',LILAC),('S',ROSE)]:
        for part in ['', 'H','T']:
            c=Canvas(50,16)
            c.box((1,1,49,15),(*col,255),r=2)
            c.box((2,1,48,3),(*WHITE,240),r=1)
            if part in ['H','T']: c.line([(7,11),(43,11)],INK,1)
            c.save('mania-note'+kind+part)
        c=Canvas(50,32)
        # Stretch-safe constant fill with continuous edges; no LN texture seams.
        c.box((3,0,47,32),(*col,100)); c.box((3,0,5,32),(*col,210)); c.box((45,0,47,32),(*col,210)); c.save('mania-note'+kind+'L')
        for down in [False,True]:
            # Legacy receptors use a fixed vertical scale of .625 in 480-space.
            # y=4 lies (129-4)*.625 = 78.125 above bottom => HitPosition 402.
            c=Canvas(50,129)
            c.box((1,1,49,128),(*PANEL,255))
            c.box((2,2,48,7),(*col,255) if down else (*col,105),r=1)
            if down: c.box((3,9,47,38),(*col,45),r=2)
            c.line([(16,60),(34,60)],(*col,160),1.2); c.save('mania-key'+kind+('D' if down else ''))
    for name in ['mania-stage-left','mania-stage-right']:
        c=Canvas(5,480); c.box((2,0,3,479),(*LINE,255)); c.save(name)
    c=Canvas(64,8); c.line([(0,4),(64,4)],(*WHITE,190),1); c.save('mania-stage-hint')
    empty('mania-stage-bottom')
    c=Canvas(50,90)
    for y in range(90): c.line([(2,y),(48,y)],(255,255,255,round(28*(y/90)**3)),1)
    c.save('mania-stage-light')
    for n in ['lightingN','lightingL']: empty(n)
    for name,t,col in [('mania-hit300g','MAX',MINT),('mania-hit300','300',WHITE),('mania-hit200','200',LILAC),('mania-hit100','100',GOLD),('mania-hit50','50',RED),('mania-hit0','MISS',RED)]:
        label(name,t,23,col,130,42,'regular')

def build_secondary():
    # Taiko: conventional Don/Katsu tint system, clean face with stable white rim.
    for name in ['taikohitcircle','taikobigcircle']:
        c=Canvas(118,118); c.ellipse((3,3,115,115),(255,255,255,255)); c.ellipse((12,12,106,106),None,(235,235,235,255),1.4); c.save(name)
        c=Canvas(118,118); c.ellipse((3,3,115,115),None,WHITE,3)
        c.ellipse((46,53,51,58),INK); c.ellipse((67,53,72,58),INK)
        if name=='taikobigcircle': c.ellipse((8,8,110,110),None,(*WHITE,180),1)
        c.save(name+'overlay')
    for n,t,col in [('0','MISS',RED),('100','100',WHITE),('100k','100',WHITE),('300','300',MINT),('300k','300',MINT),('300g','MAX',MINT)]: label('taiko-hit'+n,t,26,col,140,50,'light')
    for name in ['taiko-flower-group','taiko-glow','taiko-bar-right-glow']: empty(name)
    for name in ['pippidonidle','pippidonclear','pippidonfail','pippidonkiai']:
        c=Canvas(100,100); ribbon(c,50,40,20,RED if name=='pippidonfail' else ROSE); c.save(name)
    c=Canvas(110,100); c.box((0,0,109,99),(*INK,245)); c.ellipse((12,8,96,92),PANEL,WHITE,2); c.line([(54,10),(54,90)],LINE,1); c.save('taiko-bar-left')
    for name in ['taiko-drum-inner','taiko-drum-outer']:
        c=Canvas(100,100)
        c.ellipse((13,13,87,87),(*ROSE,150) if name.endswith('inner') else None,(*LILAC,190),9 if name.endswith('outer') else 1)
        c.save(name)
    c=Canvas(64,100); c.box((0,0,64,99),(*INK,245)); c.line([(0,2),(64,2)],LINE,1); c.line([(0,97),(64,97)],LINE,1); c.save('taiko-bar-right')
    c=Canvas(2,100); c.line([(1,0),(1,100)],(*WHITE,70),1); c.save('taiko-barline')
    for name in ['taiko-slider','taiko-slider-fail']:
        c=Canvas(32,100); c.box((0,5,31,95),(*INK,200)); c.save(name)
    c=Canvas(16,118); c.box((0,9,16,109),(255,255,255,255)); c.line([(0,10),(16,10)],WHITE,2); c.line([(0,108),(16,108)],WHITE,2); c.save('taiko-roll-middle')
    c=Canvas(118,118); c.ellipse((3,9,115,109),(255,255,255,255),WHITE,2); c.save('taiko-roll-end')
    # Catch: conventional circular fruits and a plate catcher; distinct banana arc.
    for name in ['fruit-apple','fruit-orange','fruit-pear','fruit-grapes']:
        c=Canvas(128,128); c.ellipse((7,7,121,121),(255,255,255,255)); c.save(name)
        c=Canvas(128,128); c.ellipse((7,7,121,121),None,WHITE,2.5); c.ellipse((17,17,111,111),None,(*WHITE,90),1); c.save(name+'-overlay')
    c=Canvas(128,128); c.bezier([(25,27),(4,106),(94,125),(109,43)],(255,255,255,255),23); c.save('fruit-bananas')
    c=Canvas(128,128); c.bezier([(25,27),(4,106),(94,125),(109,43)],(*GOLD,255),2); c.save('fruit-bananas-overlay')
    c=Canvas(32,32); c.ellipse((5,5,27,27),(255,255,255,255)); c.save('fruit-drop')
    c=Canvas(32,32); c.ellipse((5,5,27,27),None,WHITE,1); c.save('fruit-drop-overlay')
    for state,col in [('idle',ROSE),('fail',RED),('kiai',MINT)]:
        c=Canvas(240,96); c.box((13,20,227,35),WHITE,r=7); c.poly([(25,35),(215,35),(194,52),(46,52)],(*col,255))
        ribbon(c,120,64,12,col); c.save('fruit-catcher-'+state)

def config(circles=False):
    head='''[General]
Name: SELENE - Ribbon%s
Author: AzuRT x Codex
Version: 2.7
AnimationFramerate: 60
CursorCentre: 1
CursorExpand: 0
CursorRotate: 0
CursorTrailRotate: 0
SliderBallFlip: 0
AllowSliderBallTint: 0
HitCircleOverlayAboveNumber: 0
LayeredHitSounds: 1
SliderStyle: 2
SpinnerFadePlayfield: 0
SpinnerFrequencyModulate: 0
SpinnerNoBlink: 1
ComboBurstRandom: 0

[Colours]
Combo1: 242,180,205
Combo2: 193,185,244
Combo3: 221,227,244
Combo4: 213,189,226
SliderBorder: 167,161,190
SliderTrackOverride: 22,23,32
SpinnerApproachCircle: 242,180,205
SongSelectActiveText: 255,255,255
SongSelectInactiveText: 235,232,245
InputOverlayText: 245,242,248
MenuGlow: 193,185,244

[Fonts]
HitCirclePrefix: default
HitCircleOverlap: 5
ScorePrefix: score
ScoreOverlap: 2
ComboPrefix: combo
ComboOverlap: 2

[CatchTheBeat]
HyperDash: 242,180,205
HyperDashFruit: 255,152,187
HyperDashAfterImage: 193,185,244
''' % (' - Circles' if circles else '')
    for k,pattern in PATTERNS.items():
        w=WIDTHS[k]; start=(480*16/9-k*w)/2
        sec=f'''\n[Mania]
Keys: {k}
ColumnStart: {start:.3f}
ColumnWidth: {','.join([str(w)]*k)}
ColumnSpacing: {','.join(['0']*max(1,k-1))}
ColumnLineWidth: {','.join(['1']*(k+1))}
BarlineHeight: 0.5
HitPosition: 402
LightPosition: 402
ScorePosition: 285
ComboPosition: 240
JudgementLine: 0
KeysUnderNotes: 1
NoteBodyStyle: 0
LightFramePerSecond: 60
SpecialStyle: 0
ColourColumnLine: 42,43,57,170
ColourBarline: 75,75,91,70
ColourJudgementLine: 245,242,248
ColourKeyWarning: 245,242,248
ColourHold: 160,239,222,255
ColourBreak: 250,122,148
StageLeft: mania-stage-left
StageRight: mania-stage-right
StageBottom: mania-stage-bottom
StageHint: mania-stage-hint
StageLight: mania-stage-light
LightingN: lightingN
LightingL: lightingL
WarningArrow: mania-warningarrow
Hit0: mania-hit0
Hit50: mania-hit50
Hit100: mania-hit100
Hit200: mania-hit200
Hit300: mania-hit300
Hit300g: mania-hit300g
'''
        for i,kind in enumerate(pattern):
            col={'1':WHITE,'2':LILAC,'S':ROSE}[kind]
            sec+=f'Colour{i+1}: '+('11,12,18,255' if kind=='1' else '17,17,26,255')+'\n'
            sec+=f'ColourLight{i+1}: {col[0]},{col[1]},{col[2]}\n'
            sec+=f'KeyImage{i}: mania-key{kind}\nKeyImage{i}D: mania-key{kind}D\n'
            for part in ['', 'H','L','T']: sec+=f'NoteImage{i}{part}: mania-note{kind}{part}\n'
        head+=sec
    return head

SR=48000
RNG=np.random.default_rng(260111)
def synth(kind='click',pitch=1000,duration=.065,gain=.32):
    t=np.arange(round(SR*duration))/SR
    if kind=='click':
        noise=RNG.normal(0,1,len(t)); smooth=np.convolve(noise,np.ones(7)/7,'same')
        a=.55*np.sin(2*np.pi*pitch*t)*np.exp(-t/0.009)+.36*smooth*np.exp(-t/.004)+.20*np.sin(2*np.pi*pitch*.48*t)*np.exp(-t/.016)
    elif kind=='clap':
        noise=RNG.normal(0,1,len(t)); a=.35*noise*np.exp(-t/.012)+.34*np.sin(2*np.pi*pitch*t)*np.exp(-t/.018)
    elif kind=='bell':
        a=sum(vol*np.sin(2*np.pi*pitch*mul*t)*np.exp(-t/dec) for mul,vol,dec in [(1,.64,.09),(2,.2,.035),(3.01,.07,.025)])
    elif kind=='thock':
        a=.65*np.sin(2*np.pi*(pitch*t+pitch*.0015*(1-np.exp(-t/.004))))*np.exp(-t/.024)+.12*RNG.normal(size=len(t))*np.exp(-t/.004)
    elif kind=='loop':
        # Exact integer cycles and periodic modulation for seamless loops.
        a=.22*np.sin(2*np.pi*240*t)+.05*np.sin(2*np.pi*480*t)
        return a*gain
    elif kind=='silence': return np.zeros_like(t)
    else: raise ValueError(kind)
    # Attack below 0.15ms; final 4ms fade. Zero mean/finite; no normalisation spike.
    a*=np.minimum(1,t/.00012)
    a*=np.minimum(1,np.maximum(0,(duration-t)/.004))
    return a*gain

def wav(name,a):
    a=np.asarray(a); assert np.isfinite(a).all() and np.max(np.abs(a))<.99
    with wave.open(str(SKIN/(name+'.wav')),'wb') as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes((a*32767).astype('<i2').tobytes())

def build_sounds():
    for sample,pitch,gain in [('normal',1220,.42),('soft',980,.40),('drum',420,.45)]:
        wav(sample+'-hitnormal',synth('thock' if sample=='drum' else 'click',pitch,.075,gain))
        wav(sample+'-hitclap',synth('clap',pitch*.85,.075,.22))
        wav(sample+'-hitwhistle',synth('bell',pitch*.62,.16,.16))
        wav(sample+'-hitfinish',synth('bell',pitch*.48,.22,.20))
        wav(sample+'-slidertick',synth('click',pitch*1.6,.032,.17))
        wav(sample+'-sliderslide',synth('loop',duration=.2,gain=.018))
        wav(sample+'-sliderwhistle',synth('loop',duration=.2,gain=.012))
    hover=['menuclick','click-short','back-button-hover','pause-hover']
    for p in ['menu-back','menu-direct','menu-edit','menu-exit','menu-freeplay','menu-multiplayer','menu-options','menu-play','pause-back','pause-continue','pause-retry']:
        hover.append(p+'-hover')
    for name in hover: wav(name,synth('click',1460,.035,.12))
    clicks=['menuhit','click-short-confirm','select-expand','select-difficulty','check-on','key-confirm','back-button-click','menu-back-click','menu-direct-click','menu-edit-click','menu-exit-click','menu-freeplay-click','menu-multiplayer-click','menu-options-click','menu-play-click','pause-back-click','pause-continue-click','pause-retry-click']
    for name in clicks: wav(name,synth('click',1140,.06,.25))
    for name in ['menuback','check-off','click-close','key-delete']: wav(name,synth('thock',620,.07,.24))
    for i in range(1,5): wav(f'key-press-{i}',synth('click',1000+110*i,.035,.14))
    for name in ['key-movement','sliderbar','metronomelow']: wav(name,synth('click',1600,.025,.13))
    wav('combobreak',synth('thock',175,.11,.35))
    wav('spinnerspin',synth('loop',duration=.2,gain=.012))
    wav('spinnerbonus',synth('bell',1320,.11,.13))
    wav('spinnerbonus-max',synth('click',1520,.04,.1))
    wav('failsound',synth('thock',140,.25,.26))
    for name in ['sectionpass','match-ready','match-confirm','match-start']: wav(name,synth('bell',740,.22,.18))
    for name in ['sectionfail','match-leave','match-notready']: wav(name,synth('thock',350,.12,.17))
    wav('match-join',synth('click',900,.06,.2))
    for name in ['count','count1s','count2s','count3s']: wav(name,synth('click',1200,.05,.2))
    wav('gos',synth('bell',900,.18,.2)); wav('readys',synth('click',740,.08,.2))
    for name in ['pause-loop','comboburst','heartbeat','fountain-shoot']: wav(name,np.zeros(4800))
    # No voice or applause recording: a short, original 3-note resolution.
    applause=np.zeros(round(SR*.65))
    for offset,p in [(0,587.33),(.10,739.99),(.20,880)]:
        a=synth('bell',p,.35,.16); j=round(SR*offset); applause[j:j+len(a)]+=a
    wav('applause',applause)
    wav('welcome',synth('bell',587.33,.3,.17)); wav('seeya',synth('bell',440,.22,.15))
    for side in ['taiko-normal','taiko-soft']:
        wav(side+'-hitnormal',synth('thock',210,.085,.48))
        wav(side+'-hitclap',synth('click',1800,.06,.37))
        wav(side+'-hitfinish',synth('thock',155,.11,.5))
        wav(side+'-hitwhistle',synth('click',2100,.07,.39))

def sprite(name): return Image.open(SKIN/(name+'@2x.png')).convert('RGBA')
def paste_center(dst,im,xy,size=None):
    if size: im=im.resize(size,Image.Resampling.LANCZOS)
    dst.alpha_composite(im,(round(xy[0]-im.width/2),round(xy[1]-im.height/2)))

def preview_standard():
    im=Image.new('RGBA',(1280,720),INK); d=ImageDraw.Draw(im)
    # Preview draws real sprite files and the actual configured combo colours.
    d.rounded_rectangle((775,352,1085,456),52,fill=(22,23,32),outline=(167,161,190),width=2)
    colors=[ROSE,LILAC,(221,227,244), (213,189,226)]
    objects=[(365,437,1,0),(485,290,2,1),(690,220,3,2),(828,404,4,3)]
    for x,y,n,col in objects:
        if n in [2,3]:
            a=sprite('approachcircle'); a.putalpha(a.getchannel('A').point(lambda v:round(v*.65)))
            paste_center(im,a,(x,y),(167 if n==2 else 215,)*2)
        base=sprite('hitcircle').resize((104,104),Image.Resampling.LANCZOS)
        ar=np.array(base); ar[:,:,:3]=(ar[:,:,:3].astype(float)*np.array(colors[col])/255).astype(np.uint8)
        paste_center(im,Image.fromarray(ar),(x,y))
        paste_center(im,sprite('hitcircleoverlay'),(x,y),(104,104))
        paste_center(im,sprite('default-'+str(n)),(x,y),(33,46))
    paste_center(im,sprite('cursor'),(350,423),(32,32))
    for x,y in [(354,429),(357,435),(360,441)]: paste_center(im,sprite('cursortrail'),(x,y),(5,5))
    # Header/score mirrors the skin font. Values are illustrative.
    def num(t,xy,prefix='score',scale=.7):
        x,y=xy
        for ch in t:
            name='dot' if ch=='.' else 'percent' if ch=='%' else 'x' if ch=='x' else ch
            a=sprite(prefix+'-'+name); a=a.resize((round(a.width*scale),round(a.height*scale)),Image.Resampling.LANCZOS)
            im.alpha_composite(a,(x,y)); x+=a.width-round(4*scale)
    num('01284350',(950,22),scale=.65); num('99.42%',(1055,72),scale=.48); num('438x',(28,640),'combo',.7)
    im.alpha_composite(sprite('scorebar-bg').resize((340,34)),(0,0)); im.alpha_composite(sprite('scorebar-colour').resize((280,8)),(5,16))
    return im

def preview_mania(k=4,circles=False):
    im=Image.new('RGBA',(720,720),INK); w=WIDTHS[k]*1.5; total=k*w; start=(720-total)/2
    d=ImageDraw.Draw(im)
    for i,kind in enumerate(PATTERNS[k]):
        x=round(start+i*w); col={'1':WHITE,'2':LILAC,'S':ROSE}[kind]
        d.rectangle((x,35,round(x+w),690),fill=(11,12,18) if kind=='1' else (17,17,26))
        d.line((x,35,x,690),fill=(42,43,57),width=1)
        # Actual note sprites scale like the lane width; sample density is illustrative.
        for row in range(6):
            if (row+i)%3==0: continue
            y=82+row*78+(i%2)*32
            a=sprite('mania-note'+kind); h=round(w*16/50)
            paste_center(im,a,(x+w/2,y),(round(w),h))
        if i in ([1] if k==4 else [1,4]):
            top=160+i*15; bottom=347+i*12
            a=sprite('mania-note'+kind+'L').resize((round(w),bottom-top),Image.Resampling.LANCZOS)
            im.alpha_composite(a,(x,top)); paste_center(im,sprite('mania-note'+kind+'H'),(x+w/2,bottom),(round(w),round(w*16/50)))
        a=sprite('mania-key'+kind+('D' if i==1 else ''))
        # Actual key textures have fixed height; .625 * 1.5 maps into this preview.
        kh=round(a.height/2*.625*1.5)
        im.alpha_composite(a.resize((round(w),kh),Image.Resampling.LANCZOS),(x,720-kh))
    d=ImageDraw.Draw(im); d.line((start,602,start+total,602),fill=WHITE,width=2)
    paste_center(im,sprite('mania-hit300g'),(360,428),(130,42))
    # Deliberately no opaque art above notes.
    return im

def contact_sheet():
    c=Canvas(1920,1460,(*INK,255))
    ribbon(c,83,62,24); c.text((135,62),'S É L È N E',34,WHITE,'light','lm')
    c.text((1836,64),'RIBBON EDITION   /   01',14,MUTED,'mono','rm')
    c.text((64,129),'Soft palette. Sharp focus.',53,WHITE,'light','lm')
    c.text((66,188),'OSU!STANDARD + MANIA    /    ASSETS ORIGINAUX    /    SD + HD',13,MUTED,'mono','lm')
    im=c.im.resize((1920,1460),Image.Resampling.LANCZOS)
    im.alpha_composite(preview_standard().resize((1166,656)),(64,245))
    d=ImageDraw.Draw(im)
    f=lambda n,s='regular':ImageFont.truetype(str(FONTDIR/FONT[s]),n)
    d.text((66,924),'01 / STANDARD',font=f(14,'mono'),fill=ROSE)
    d.text((66,956),'Cercles nets · sliders sombres · curseur menthe',font=f(22,'light'),fill=WHITE)
    # Crop the empty side margins; never squash the gameplay's aspect ratio.
    m4=preview_mania(4).crop((210,0,510,720)).resize((242,580))
    m7=preview_mania(7).crop((150,0,570,720)).resize((338,580))
    im.alpha_composite(m4,(1270,245)); im.alpha_composite(m7,(1522,245))
    d=ImageDraw.Draw(im)
    d.text((1290,850),'02 / MANIA 4K + 7K',font=f(14,'mono'),fill=LILAC)
    d.text((1290,883),'Barres / LN / contraste stable',font=f(20,'light'),fill=WHITE)
    d.line((64,1025,1856,1025),fill=LINE,width=1)
    # A truthful asset board of menu parts; not a fabricated in-game menu screenshot.
    im.alpha_composite(sprite('pause-continue').resize((320,76)),(64,1072))
    im.alpha_composite(sprite('pause-retry').resize((320,76)),(64,1166))
    for i,n in enumerate(['mode','mods','random','options']):
        a=sprite('selection-'+n); a=a.resize((round(a.width*.65),117))
        im.alpha_composite(a,(456+i*111,1092))
    for i,n in enumerate(['hidden','doubletime','hardrock','nightcore']):
        im.alpha_composite(sprite('selection-mod-'+n).resize((82,70)),(456+i*111,1230))
    im.alpha_composite(sprite('ranking-S').resize((210,140)),(997,1092))
    for i,col in enumerate([ROSE,LILAC,WHITE,MINT]): d.ellipse((1302+i*115,1110,1350+i*115,1158),fill=col)
    d.text((1290,1192),'03 / INTERFACE + SOUND',font=f(14,'mono'),fill=ROSE)
    d.text((1290,1228),'Clics courts, mats et synthétisés.',font=f(21,'light'),fill=WHITE)
    d.text((64,1392),'COMPOSITIONS DES ASSETS • APERÇUS HORS JEU • VALEURS DE SCORE ILLUSTRATIVES',font=f(12,'mono'),fill=MUTED)
    im.convert('RGB').save(OUT/'SELENE-apercu.jpg',quality=94,subsampling=0)
    preview_standard().convert('RGB').save(ROOT/'work'/'standard-preview.jpg',quality=95)

def validate():
    errors=[]; images=0; sounds=0; peaks={}
    for p in SKIN.glob('*.png'):
        with Image.open(p) as im:
            im.load(); images+=1
            if '@2x' not in p.stem:
                hd=p.with_stem(p.stem+'@2x')
                if hd.exists():
                    with Image.open(hd) as high:
                        if high.size!=(im.width*2,im.height*2): errors.append('HD size '+p.name)
    for p in SKIN.glob('*.wav'):
        with wave.open(str(p),'rb') as f:
            if f.getframerate()!=SR or f.getnchannels()!=1: errors.append('audio format '+p.name)
            a=np.frombuffer(f.readframes(f.getnframes()),'<i2').astype(float)/32767
            peak=float(np.max(np.abs(a))); peaks[p.name]=round(peak,4)
            if peak>=.99: errors.append('clipping '+p.name)
            sounds+=1
    for k,pat in PATTERNS.items():
        if len(pat)!=k: errors.append(f'Pattern {k}: {len(pat)}')
    txt=config()
    for line in txt.splitlines():
        if re.match(r'(NoteImage|KeyImage|StageLeft|StageRight|StageBottom|StageLight|StageHint|LightingN|LightingL|WarningArrow|Hit[0-9])',line) and ':' in line:
            path=line.split(':',1)[1].strip()
            if not (SKIN/(path+'.png')).exists(): errors.append('Missing '+path)
    report={'status':'PASS' if not errors else 'FAIL','png_files':images,'wav_files':sounds,'mania_keycounts':list(PATTERNS),'png_SD_HD_dimensions':'checked','mania_asset_references':'checked','audio':'mono PCM16 48000 Hz; no clipping','max_audio_peak':max(peaks.values()),'in_game_test':False,'errors':errors}
    (ROOT/'work'/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    assert not errors,errors
    return report

def documentation(report):
    guide='''# SÉLÈNE / ribbon edition — v1.0

Un skin original pour AzuRT : anthracite, nacre, rose poudré, lavande et curseur menthe.
Priorité à osu!standard et osu!mania, avec une interface cohérente, des clics courts et des effets contenus.

## Installation
Double-clique sur **SELENE - Ribbon.osk**, ou glisse-le dans la fenêtre d'osu!, puis sélectionne le skin dans les options.
**SELENE - Ribbon - Circles.osk** est une variante complète : seuls les notes et récepteurs de mania changent pour des cercles. Tu peux importer les deux et alterner dans le jeu.

## Ce qui est inclus
- Standard : cercles sombres, bord blanc et anneau teinté ; chiffres lisibles ; approche fine ; followpoints courts ; sliders sombres ; curseur menthe fixe ; spinner à repères ; 100/50/miss visibles ; 300 masqués pour réduire les distractions.
- Mania : 4K blanc/lavande/lavande/blanc ; 7K blanc/lavande/blanc/rose/blanc/lavande/blanc. Barres et têtes de LN pleines, corps plus doux bordés, tails séparées, récepteurs discrets. Configurations pour 1–10K, 12K, 14K, 16K et 18K. 4K et 7K sont les priorités de conception. Aucun changement de touches ou de vitesse de défilement.
- Taiko : notes rondes Don/Katsu utilisant la coloration native rouge/bleu, gros hits bordés, piste sombre, jugements sobres.
- Catch : fruits ronds classiques, bananes courbes et catcher en plateau avec repère rose. Hyperdash rose vif.
- Interface legacy : boutons de sélection, mods, pause, échec, résultats, grades, compteurs et barre de vie.
- Sons originaux synthétisés en PCM mono 16 bits / 48 kHz. Attaque très courte ; normal, soft, drum, taiko, ticks, menus et confirmations distincts. Pas de voix, de musique ajoutée ni de longue réverbération. Pause silencieuse.
- Fichiers SD et @2x pour les éléments PNG.

## Réglages de départ, à adapter à ton confort
- Fond de beatmap : assombrissement 90–100 % ; les aperçus utilisent un fond quasi noir.
- Effets et storyboards : les désactiver si tu veux une lecture plus calme.
- Curseur : commencer autour de 1×, ajuster à ta résolution et ta tablette/souris.
- Volume effets : commencer à 45–65 %, puis ajuster en jouant. Aucun volume système n'est modifié.
- Pour entendre les clics du skin, désactiver « utiliser les hitsounds des beatmaps » si cette option est disponible dans ton client. Les samples personnalisés des maps et les options du client peuvent autrement prendre le dessus.
- Mania : descente par défaut du client, HitPosition 402/480 ; largeurs 46 en 4K, 40 en 7K. Le skin ne force pas le sens de défilement. Les positions ColumnStart sont calculées pour centrer en 16:9 dans le client legacy ; les autres formats nécessitent un ajustement et lazer peut gérer le placement différemment.

## Limites et vérifications
Le pack cible le format de skin legacy d'osu!stable. osu!lazer peut importer ce format, mais sa navigation et certains éléments restent ceux de lazer ; un .osk ne remplace pas toute son interface. Le fond personnalisé du menu principal dépend d'osu!supporter et des options du client stable.

Les aperçus sont des compositions des vrais assets, pas des captures d'écran du jeu. Aucun essai de gameplay dans un client n'a été réalisé. Une validation technique contrôle les PNG, les correspondances SD/@2x, les références mania, les keycounts, les WAV, l'absence de saturation numérique et l'intégrité des archives. Il faut encore juger le confort et le placement en jouant sur ta configuration ; « centré pro » est ici un objectif de conception, pas une promesse de performance.

## Direction artistique et crédits
Référence demandée : « mizuki akiyama! (sleepy + aristia + various) ». Le mix exact n'a pas pu être identifié avec certitude. Cette création reprend l'intention pastel et épurée, sans prétendre reproduire ses assets. Ruban asymétrique, courbes et palette créés pour ce pack ; pas de portrait ou d'illustration de personnage.
Taiko et catch reprennent des conventions classiques de lisibilité plutôt que les fichiers d'un skin tiers.
Images et sons construits localement par le générateur fourni ; les polices Segoe UI de Windows sont rasterisées, aucun fichier de police n'est distribué. Aucun sample tiers n'est inclus.

## Sources techniques
- https://osu.ppy.sh/wiki/en/Skinning/skin.ini
- https://osu.ppy.sh/wiki/en/Skinning/Interface
- https://osu.ppy.sh/wiki/en/Skinning/osu!mania
- https://osu.ppy.sh/wiki/en/Skinning/osu!taiko
- https://osu.ppy.sh/wiki/en/Skinning/osu!catch
- https://osu.ppy.sh/wiki/en/Skinning/Sounds
- https://skinship.redo.ac/tutorial/mania.html

## Sources modifiables
SELENE-sources.zip contient le générateur, ce guide et le rapport de validation. Sur Windows avec Python 3.12+ : installer Pillow et numpy, placer le script dans un dossier work à côté d'outputs, puis l'exécuter. Les fichiers sont écrits dans work/SELENE - Ribbon et les livrables dans outputs.
'''
    (SKIN/'LISEZ-MOI.txt').write_text(guide,encoding='utf8')
    (OUT/'SELENE-guide.md').write_text(guide,encoding='utf8')
    # A self-contained local sound/asset viewer. All audio is embedded, no requests.
    snd=[]
    for name,title in [('normal-hitnormal','Nacre / normal'),('soft-hitnormal','Soft / mat'),('drum-hitnormal','Drum / thock'),('normal-hitclap','Clap / court'),('normal-hitfinish','Finish / cristallin'),('menuclick','Survol du menu'),('menuhit','Confirmation'),('combobreak','Combo break'),('taiko-normal-hitnormal','Taiko / Don'),('taiko-normal-hitclap','Taiko / Katsu')]:
        uri=base64.b64encode((SKIN/(name+'.wav')).read_bytes()).decode()
        snd.append(f'<button onclick="play(\'{name}\')"><span>▶</span> {title}</button><audio id="{name}" src="data:audio/wav;base64,{uri}"></audio>')
    jpg=base64.b64encode((OUT/'SELENE-apercu.jpg').read_bytes()).decode()
    bgjpg=base64.b64encode((SKIN/'menu-background.jpg').read_bytes()).decode()
    html='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SÉLÈNE / ribbon edition</title>
<style>*{box-sizing:border-box}body{margin:0;background:#0c0e15;color:#f5f2f8;font:16px/1.65 'Segoe UI',sans-serif}main{max-width:1260px;margin:auto;padding:64px 28px}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #3c3d4e;padding-bottom:22px}header b{font-size:20px;letter-spacing:.4em;font-weight:300}small,.muted{color:#8f8fa4}h1{font-size:clamp(38px,6vw,68px);font-weight:300;line-height:1.1;margin:56px 0 18px}h2{font-size:27px;font-weight:300;margin-top:52px}.tag{font:12px monospace;letter-spacing:.13em;color:#f2b4cd}img{width:100%;border-radius:14px;margin-top:28px}.sounds{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px}button,.link{border:1px solid #3c3d4e;background:#181a25;border-radius:9px;padding:17px;color:#f5f2f8;cursor:pointer;font:inherit;text-align:left}button:hover{border-color:#f2b4cd}button span{color:#a0efde;margin-right:10px}.links{display:flex;flex-wrap:wrap;gap:12px;margin-top:26px}.link{display:inline-block;text-decoration:none}.primary{background:#f2b4cd;color:#12121b;border-color:#f2b4cd}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:24px}.card{background:#141620;border:1px solid #292b3b;border-radius:12px;padding:24px}.card h3{color:#c1b9f4;font-size:18px;font-weight:400}.notice{border-left:2px solid #c1b9f4;padding:4px 20px;color:#b9b8cd;margin:32px 0}footer{margin-top:60px;border-top:1px solid #3c3d4e;padding-top:24px;color:#8f8fa4;font-size:13px}a{color:#f2b4cd}</style>
<main><header><b>SÉLÈNE</b><small>RIBBON EDITION / 01</small></header><h1>Soft palette.<br>Sharp focus.</h1><p class="tag">OSU!STANDARD + MANIA / MINIMAL / NACRE & LAVANDE</p><p class="muted">Un univers pastel discret, des repères francs et des clics mats. Créé pour AzuRT.</p><div class="links"><a class="link primary" href="SELENE%20-%20Ribbon.osk">Importer le skin · barres</a><a class="link" href="SELENE%20-%20Ribbon%20-%20Circles.osk">Variante mania · cercles</a><a class="link" href="SELENE-guide.md">Lire le guide</a></div>
<img alt="Compositions des vrais assets standard, mania 4K et 7K, interface" src="data:image/jpeg;base64,IMAGE"><p class="muted">Aperçus composés à partir des assets. Ce ne sont pas des captures en jeu.</p>
<h2>Une texture sonore courte et nette.</h2><p class="muted">Volume de préécoute volontairement modéré. Les sons ne se superposent pas dans cette galerie.</p><div class="sounds">SOUNDS</div>
<h2>Le confort guide le dessin.</h2><div class="cards"><article class="card"><h3>01 / Standard</h3><p>Centre sombre, bord blanc, approche fine. Rose, lavande et nacre pour les combos. Curseur menthe fixe. Les 300 s'effacent ; les erreurs restent visibles.</p></article><article class="card"><h3>02 / Mania</h3><p>Barres contrastées et LN bordées. 4K en blanc/lavande et 7K avec une touche centrale rose. Variante cercles complète incluse. Autres configurations de touches également fournies.</p></article><article class="card"><h3>03 / Interface</h3><p>Ruban asymétrique, boutons sobres, grades fins et pause calme. Taiko et catch utilisent des formes classiques assorties à la palette.</p></article></div>
<h2>Installation en un geste.</h2><p>Ouvre le fichier <b>.osk</b> ou glisse-le dans osu!, puis choisis SÉLÈNE dans les options de skin. La variante cercles est un second skin complet. Pour découvrir les sons, vérifie les options de hitsounds des beatmaps.</p><div class="notice">Format legacy osu!stable. Dans lazer, l'interface de navigation conserve ses propres règles. Le fond du menu principal stable dépend d'osu!supporter. Centrage mania prévu en 16:9. Les images, références et sons sont vérifiés techniquement ; le pack n'a pas encore été testé en gameplay.</div>
<p class="muted">Conception originale inspirée de l'intention pastel et minimaliste demandée. Le mix Mizuki/Sleepy/Aristia exact n'a pas été identifié avec certitude. Aucun asset ni enregistrement de ce mix n'a été repris.</p><footer>SÉLÈNE / v1.0 · AzuRT x Codex · <a href="SELENE-sources.zip">Sources modifiables</a> · <a href="https://osu.ppy.sh/wiki/en/Skinning">Documentation osu!</a></footer></main>
<script>function play(id){document.querySelectorAll('audio').forEach(a=>{a.pause();a.currentTime=0});let a=document.getElementById(id);a.volume=.65;a.play().catch(()=>{})}</script></html>'''.replace('IMAGE',jpg).replace('SOUNDS',''.join(snd))
    html=html.replace('<h2>Une texture sonore',f'<h2>Le ruban comme signature.</h2><img alt="Fond de menu original SÉLÈNE avec courbes de ruban rose et lavande" src="data:image/jpeg;base64,{bgjpg}"><p class="muted">Fond inclus dans le pack. Affichage du menu principal stable soumis à osu!supporter et aux options du client.</p><h2>Une texture sonore')
    (OUT/'SELENE-galerie.html').write_text(html,encoding='utf8')

def circle_variant():
    alt=ROOT/'work'/'SELENE - Ribbon - Circles'; alt.mkdir(exist_ok=True)
    for p in SKIN.iterdir():
        if p.is_file(): shutil.copyfile(p,alt/p.name)
    original=SKIN
    # Render distinct circle/receptor sprites in a temporary directory by global target.
    globals()['SKIN']=alt
    for kind,col in [('1',WHITE),('2',LILAC),('S',ROSE)]:
        for part in ['', 'H','T']:
            c=Canvas(50,50); c.ellipse((3,3,47,47),(*col,255),WHITE,1)
            c.ellipse((10,10,40,40),None,(*INK,90),1)
            if part in ['H','T']: c.ellipse((20,20,30,30),(*INK,130))
            c.save('mania-note'+kind+part)
        for down in [False,True]:
            # Centre of receptor at y=25; (150-25)*.625 = 78.125.
            c=Canvas(50,150)
            c.box((0,25,50,150),(*PANEL,255))
            c.ellipse((3,3,47,47),(*col,100) if down else (*INK,255),col,2)
            c.ellipse((20,20,30,30),col if down else (*col,120))
            c.save('mania-key'+kind+('D' if down else ''))
    (alt/'skin.ini').write_text(config(True),encoding='utf8')
    globals()['SKIN']=original
    return alt

def pack(folder,target):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(folder.iterdir()):
            if p.is_file(): z.write(p,p.name)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None and 'skin.ini' in z.namelist()

def main():
    for title,fn in [('standard',build_standard),('interface',build_interface),('background',build_background),('mania',build_mania),('taiko + catch',build_secondary),('audio',build_sounds)]:
        fn(); print(title+' ready',flush=True)
    (SKIN/'skin.ini').write_text(config(),encoding='utf8')
    report=validate(); print(json.dumps(report),flush=True)
    contact_sheet(); documentation(report)
    alt=circle_variant()
    pack(SKIN,OUT/'SELENE - Ribbon.osk')
    pack(alt,OUT/'SELENE - Ribbon - Circles.osk')
    with zipfile.ZipFile(OUT/'SELENE-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.write(__file__,'work/build_selene.py'); z.write(ROOT/'work'/'validation.json','validation.json'); z.write(OUT/'SELENE-guide.md','LISEZ-MOI.md')
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.osk')}
    (ROOT/'work'/'package-hashes.json').write_text(json.dumps(hashes,indent=2))
    print('PACKAGED '+json.dumps(hashes),flush=True)

if __name__=='__main__': main()
