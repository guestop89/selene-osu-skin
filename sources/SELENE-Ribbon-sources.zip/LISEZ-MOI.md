# SÉLÈNE / ribbon edition — v1.0

Un skin original pour AzuRT : anthracite, nacre, rose poudré, lavande et curseur menthe.
Priorité à osu!standard et osu!mania, avec une interface cohérente, des clics courts et des effets contenus.

## Installation
Double-clique sur **SELENE - Ribbon.osk**, ou glisse-le dans la fenêtre d'osu!, puis sélectionne le skin dans les options.

## Ce qui est inclus
- Standard : cercles sombres, bord blanc et anneau teinté ; chiffres lisibles ; approche fine ; followpoints courts ; sliders sombres ; curseur menthe fixe ; spinner à repères ; 100/50/miss visibles ; 300 masqués pour réduire les distractions.
- Mania : 4K blanc/lavande/lavande/blanc ; 7K blanc/lavande/blanc/rose/blanc/lavande/blanc. Barres et têtes de LN pleines, corps plus doux bordés, tails séparées, récepteurs discrets. Configurations pour 1–10K, 12K, 14K, 16K et 18K. 4K et 7K sont les priorités de conception. Aucun changement de touches ou de vitesse de défilement.
- Taiko : notes rondes Don/Katsu utilisant la coloration native rouge/bleu, gros hits bordés, piste sombre, jugements sobres.
- Catch : fruits ronds classiques, bananes courbes et catcher en plateau avec repère rose. Hyperdash rose vif.
- Interface legacy : boutons de sélection, mods, pause, échec, résultats, grades, compteurs et barre de vie.
- Sons originaux synthétisés en PCM mono 16 bits / 48 kHz. Attaque très courte ; normal, soft, drum, taiko, ticks, menus et confirmations distincts. Pas de voix, de musique ajoutée ni de longue réverbération. Pause silencieuse.
- Fichiers SD et @2x pour les éléments PNG.

## Réglages de départ, à adapter à ton confort
- Fond de beatmap : assombrissement 90–100 % ; les aperçus utilisent un fond quasi noir.
- Effets et storyboards : les désactiver si tu veux une lecture plus calme.
- Curseur : commencer autour de 1×, ajuster à ta résolution et ta tablette/souris.
- Volume effets : commencer à 45–65 %, puis ajuster en jouant. Aucun volume système n'est modifié.
- Pour entendre les clics du skin, désactiver « utiliser les hitsounds des beatmaps » si cette option est disponible dans ton client. Les samples personnalisés des maps et les options du client peuvent autrement prendre le dessus.
- Mania : descente par défaut du client, HitPosition 402/480 ; largeurs 46 en 4K, 40 en 7K. Le skin ne force pas le sens de défilement. Les positions ColumnStart sont calculées pour centrer en 16:9 dans le client legacy ; les autres formats nécessitent un ajustement et lazer peut gérer le placement différemment.

## Limites et vérifications
Le pack cible le format de skin legacy d'osu!stable. osu!lazer peut importer ce format, mais sa navigation et certains éléments restent ceux de lazer ; un .osk ne remplace pas toute son interface. Le fond personnalisé du menu principal dépend d'osu!supporter et des options du client stable.

Les aperçus sont des compositions des vrais assets, pas des captures d'écran du jeu. Aucun essai de gameplay dans un client n'a été réalisé. Une validation technique contrôle les PNG, les correspondances SD/@2x, les références mania, les keycounts, les WAV, l'absence de saturation numérique et l'intégrité des archives. Il faut encore juger le confort et le placement en jouant sur ta configuration ; « centré pro » est ici un objectif de conception, pas une promesse de performance.

## Direction artistique et crédits
Référence demandée : « mizuki akiyama! (sleepy + aristia + various) ». Le mix exact n'a pas pu être identifié avec certitude. Cette création reprend l'intention pastel et épurée, sans prétendre reproduire ses assets. Ruban asymétrique, courbes et palette créés pour ce pack ; pas de portrait ou d'illustration de personnage.
Taiko et catch reprennent des conventions classiques de lisibilité plutôt que les fichiers d'un skin tiers.
Images et sons construits localement par le générateur fourni ; les polices Segoe UI de Windows sont rasterisées, aucun fichier de police n'est distribué. Aucun sample tiers n'est inclus.

## Sources techniques
- https://osu.ppy.sh/wiki/en/Skinning/skin.ini
- https://osu.ppy.sh/wiki/en/Skinning/Interface
- https://osu.ppy.sh/wiki/en/Skinning/osu!mania
- https://osu.ppy.sh/wiki/en/Skinning/osu!taiko
- https://osu.ppy.sh/wiki/en/Skinning/osu!catch
- https://osu.ppy.sh/wiki/en/Skinning/Sounds
- https://skinship.redo.ac/tutorial/mania.html

## Sources modifiables
SELENE-sources.zip contient le générateur, ce guide et le rapport de validation. Sur Windows avec Python 3.12+ : installer Pillow et numpy, placer le script dans un dossier work à côté d'outputs, puis l'exécuter. Les fichiers sont écrits dans work/SELENE - Ribbon et les livrables dans outputs.
