from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
with ZipFile(root / 'base-v1.5.osk') as archive:
    files = {name: archive.read(name) for name in archive.namelist()}
for suffix in ('', '@2x'):
    name = f'scorebar-bg{suffix}.png'
    files[name] = (root / name).read_bytes()
files['skin.ini'] = files['skin.ini'].replace(b'Name: SELENE V1.5 Reference', b'Name: SELENE V2.0').replace(b'Release: 1.5 Reference', b'Release: 2.0')
files['release.json'] = (root / 'release.json').read_bytes()
with ZipFile(root / 'SELENE-V2.0.osk', 'w', ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)
print('SELENE-V2.0.osk rebuilt')
