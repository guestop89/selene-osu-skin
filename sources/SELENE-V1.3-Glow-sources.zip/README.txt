Aura générée avec image_gen puis composée autour du cœur nacré. Prompt résumé : nuage de lumière irrégulier lilas, violet et rose, compact, transparent et sans contours durs.
Exécuter python build.py pour reconstruire le .osk depuis les PNG et le skin de base.
