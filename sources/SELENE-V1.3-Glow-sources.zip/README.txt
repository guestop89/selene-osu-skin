Run python build.py to rebuild the skin using the supplied PNGs.
Generated using built-in image_gen; resized with ImageMagick to 96x96, centered on a transparent 216x216 canvas for HD, then resized to 108x108 for SD.
Prompt: single perfectly circular smooth luminous pearl orb; pearl white center, pale lavender body, slim luminous violet rim and very short subtle bloom; transparent background; no text or objects.
