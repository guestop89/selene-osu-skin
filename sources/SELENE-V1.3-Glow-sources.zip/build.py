from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
r=Path(__file__).resolve().parent
with ZipFile(r/'base-v1.2.osk') as z: files={n:z.read(n) for n in z.namelist()}
for n in ['cursor.png','cursor@2x.png']: files[n]=(r/n).read_bytes()
files['skin.ini']=files['skin.ini'].replace(b'Name: SELENE V1.2 Realease',b'Name: SELENE V1.3 Glow').replace(b'// Release: 1.0 / AzuRT',b'// Release: 1.3 Glow / AzuRT')
with ZipFile(r/'SELENE-V1.3-Glow.osk','w',ZIP_DEFLATED) as z:
 for n,b in files.items(): z.writestr(n,b)
print('SELENE-V1.3-Glow.osk rebuilt')
