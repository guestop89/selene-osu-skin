from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
sprites = ['cursor.png', 'cursor@2x.png', 'cursortrail.png', 'cursortrail@2x.png']
with ZipFile(root / 'base.osk') as base:
    with ZipFile(root / 'SELENE-V1.3-Glow.osk', 'w', ZIP_DEFLATED) as target:
        for name in base.namelist():
            data = (root / name).read_bytes() if name in sprites else base.read(name)
            target.writestr(name, data)
